# Initial Safety / Acceptance Checklist

- [ ] No order execution capability exists.
- [ ] MT5 connection is read-only.
- [ ] Forming-candle events remain provisional.
- [ ] Confirmed structure requires closed-candle rules.
- [ ] Every result includes instrument, timeframe, UTC timestamp and provenance.
- [ ] Conflicts and contrary evidence are preserved.
- [ ] Missing data is not treated as negative evidence.
- [ ] Shared Core cannot be auto-promoted by private user activity.
- [ ] Private trader data is tenant-isolated.
- [ ] Scanner and Brain retain independent conclusions.
- [ ] Strategy claims are validated with reproducible replay/out-of-sample tests.
- [ ] Provider/API secrets are not committed.
