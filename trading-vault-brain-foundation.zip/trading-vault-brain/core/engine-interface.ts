import type { AnalysisRequest, EngineResult } from "./types";

/**
 * Every specialist engine must be independently testable and return
 * provenance-rich evidence. Implementations must not execute trades.
 */
export interface SpecialistEngine {
  readonly id: string;
  readonly version: string;
  analyze(request: AnalysisRequest): Promise<EngineResult[]>;
}
