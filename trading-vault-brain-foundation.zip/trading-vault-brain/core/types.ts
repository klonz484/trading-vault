/**
 * Shared types for Trading Vault Brain.
 * This package intentionally has no runtime dependencies yet.
 */

export type EventState =
  | "provisional"
  | "confirmed"
  | "invalidated"
  | "unavailable";

export type Direction = "bullish" | "bearish" | "neutral" | "unknown";

export interface EvidenceItem {
  id: string;
  description: string;
  observedAt: string;
  timeframe: string;
  source: string;
  weight?: number;
  metadata?: Record<string, unknown>;
}

export interface EngineResult {
  schemaVersion: "1.0.0";
  engineId: string;
  instrument: string;
  timeframe: string;
  observedAt: string;
  state: EventState;
  direction: Direction;
  confidence: number | null;
  evidence: EvidenceItem[];
  contraryEvidence: EvidenceItem[];
  invalidation: Record<string, unknown> | null;
  sourceRefs: string[];
  warnings: string[];
}

export interface AnalysisRequest {
  requestId: string;
  userId: string;
  instrument: string;
  timeframes: string[];
  requestedAt: string;
  mode: "user_triggered" | "market_event";
}
