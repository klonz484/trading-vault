import type { AnalysisRequest, EngineResult } from "./types";
import type { SpecialistEngine } from "./engine-interface";

export interface OrchestrationResult {
  requestId: string;
  results: EngineResult[];
  warnings: string[];
}

/**
 * Minimal orchestration boundary. Production orchestration still needs
 * timeouts, cancellation, retries, priority scheduling and observability.
 */
export async function runSpecialists(
  request: AnalysisRequest,
  engines: SpecialistEngine[],
): Promise<OrchestrationResult> {
  const settled = await Promise.allSettled(
    engines.map((engine) => engine.analyze(request)),
  );

  const results: EngineResult[] = [];
  const warnings: string[] = [];

  settled.forEach((item, index) => {
    if (item.status === "fulfilled") {
      results.push(...item.value);
    } else {
      warnings.push(
        `Engine ${engines[index]?.id ?? "unknown"} unavailable: ${String(item.reason)}`,
      );
    }
  });

  return { requestId: request.requestId, results, warnings };
}
