# Reasoning Engine

Status: interface placeholder — not production logic.

Responsibilities, inputs, outputs, validation and dependencies are defined in
`documentation/ENGINE_SPECIFICATIONS.md`.

Implementation requirements:
- Implement `SpecialistEngine` from `core/engine-interface.ts`.
- Preserve evidence provenance and UTC timestamps.
- Return explicit event state; never silently confirm provisional events.
- Include contrary evidence and warnings where relevant.
- Do not place, modify or close trades.
- Add unit tests and replay fixtures before enabling this engine.
