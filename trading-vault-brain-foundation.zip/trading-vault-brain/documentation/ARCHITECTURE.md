# Trading Vault Brain Architecture

## Approved direction

| Area | Decision |
|---|---|
| Brain type | Hybrid Brain |
| Methodology | Hybrid: ICT + SMC + price action + indicators |
| Execution | Manual MT5 only; no automatic order execution |
| Market scope | Forex majors + Gold (`forex_gold`) |
| Data sourcing | Hybrid: MT5 broker feed + independent provider |
| Scanner relationship | Independent pipelines with controlled collaboration |
| Final analytical authority | Collaborative, with conflicts and uncertainty visible |
| Knowledge | Shared Core + private trader knowledge |
| Learning | Controlled experiments |
| Shared Core changes | Testing and owner approval required |

## Processing flow

Market data → data validation → market context → specialist engines → evidence aggregation → confluence/conflict analysis → central reasoning → risk/quality validation → structured analysis → trader review → manual MT5 execution.

A separate learning path records private outcomes, runs controlled experiments, evaluates evidence and proposes candidate improvements. It cannot directly mutate Shared Core knowledge.

## Separation principles

1. The Brain and Scanner keep separate analytical pipelines and independent conclusions.
2. They exchange structured, versioned evidence only.
3. Each conclusion retains source, timestamp, timeframe, provenance and uncertainty.
4. Imported findings are evidence, not commands.
5. A collaborative final view explains agreement, disagreement and missing evidence.
6. User data is tenant-isolated. Shared Core content is centrally governed.

## Specialist engines

- Market Data
- Market Context / Regime
- Market Structure
- Liquidity
- ICT
- SMC
- Price Action
- Indicators
- Sessions
- News / Economic Calendar
- Strategy
- Confluence
- Risk
- AI Reasoning / Orchestration
- Memory / Knowledge
- Experimental Learning
- Performance / Validation

Each engine must implement a common input/output envelope and must report `provisional`, `confirmed`, `invalidated`, or `unavailable` where applicable.
