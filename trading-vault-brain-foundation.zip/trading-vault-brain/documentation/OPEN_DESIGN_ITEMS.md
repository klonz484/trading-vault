# Open Design Items — Do Not Guess

These items must be decided or explicitly assigned a safe default before production implementation:

1. Independent market-data provider and exact MT5 read-only integration.
2. Hosting topology, ingestion cadence, retention and historical correction policy.
3. Engine-by-engine JSON schemas, event names, IDs, versioning and error semantics.
4. Exact ICT/SMC definitions and numeric thresholds not already approved.
5. Strategy catalogue, entry/exit logic, scoring and backtest/replay acceptance criteria.
6. Risk sizing: account currency, pip/point values, contract sizes, broker symbol suffixes and assumptions.
7. AI provider/model, fallback, latency/cost budget and deterministic boundaries.
8. News/calendar provider, event mapping and blackout policy.
9. Supabase schema, RLS policies, storage buckets, retention/export/deletion and audit model.
10. Monitoring, dashboards, alert routing and degraded-mode policy.
11. Experiment sample sizes, out-of-sample rules, fees/spread/slippage and promotion gates.
12. Security review, test coverage, performance targets and rollback plan.

Decision 366 is next in the overall numbered ledger, but its exact wording/options are not available in this package source. Recover it from the original planning conversation before recording a selection.
