# Extraction Guide — GitHub Codespaces

## Before extracting
- Confirm the Codespace is open on the intended repository and branch.
- Run `pwd` and `git status --short --branch`.
- Do not extract over existing files without reviewing conflicts.
- This package is intended to add a new `trading-vault-brain/` directory at the repository root.

## Upload the ZIP
Download the ZIP from this conversation to your device. In the Codespaces VS Code Explorer, use the upload-files action to upload `trading-vault-brain-foundation.zip` into the repository root.

## Extract
In the Codespaces terminal, run:

```bash
pwd
git status --short --branch
unzip -l trading-vault-brain-foundation.zip
unzip -n trading-vault-brain-foundation.zip
```

`-n` prevents overwriting existing files. If it reports that files already exist, stop and inspect the conflicts rather than forcing extraction.

## Verify
```bash
find trading-vault-brain -maxdepth 3 -type f | sort
git status --short
```

## Next
Do not commit or push until the extracted tree has been reviewed. The next development stage is to implement one engine at a time behind the contracts, then add database migrations only after the multi-user/RLS design is reviewed.
