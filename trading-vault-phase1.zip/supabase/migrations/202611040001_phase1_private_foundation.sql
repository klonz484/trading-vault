-- Trading Vault Phase 1: private per-user foundation.
-- Run once in the Supabase SQL Editor. Review before applying to a live project.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.chart_scans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  instrument text not null,
  timeframe text,
  image_path text,
  analysis jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.journal_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  instrument text not null,
  direction text check (direction in ('buy', 'sell', 'no_trade')),
  entry_price numeric,
  stop_loss numeric,
  take_profit jsonb,
  result_r numeric,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.trading_experiments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  hypothesis text,
  method text,
  outcome jsonb,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.chart_scans enable row level security;
alter table public.journal_entries enable row level security;
alter table public.trading_experiments enable row level security;

create policy "Users can read their own profile"
on public.profiles for select to authenticated
using ((select auth.uid()) = id);

create policy "Users can create their own profile"
on public.profiles for insert to authenticated
with check ((select auth.uid()) = id);

create policy "Users can update their own profile"
on public.profiles for update to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

create policy "Users can manage their own chart scans"
on public.chart_scans for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "Users can manage their own journal entries"
on public.journal_entries for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

create policy "Users can manage their own experiments"
on public.trading_experiments for all to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

-- Create a private bucket. User files must be stored under <auth.uid()>/...
insert into storage.buckets (id, name, public)
values ('chart-images', 'chart-images', false)
on conflict (id) do nothing;

create policy "Users can view their own chart images"
on storage.objects for select to authenticated
using (
  bucket_id = 'chart-images'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

create policy "Users can upload their own chart images"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'chart-images'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

create policy "Users can update their own chart images"
on storage.objects for update to authenticated
using (
  bucket_id = 'chart-images'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
)
with check (
  bucket_id = 'chart-images'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

create policy "Users can delete their own chart images"
on storage.objects for delete to authenticated
using (
  bucket_id = 'chart-images'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);
