"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setMessage("");
    setBusy(true);

    try {
      const supabase = createClient();
      const { error: signupError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback?next=/`,
        },
      });

      if (signupError) throw signupError;

      setMessage("Account request received. Check your email for the verification link before signing in.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create the account.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[var(--background)] px-5 py-12 text-[var(--foreground)]">
      <section className="w-full max-w-md rounded-2xl border border-[var(--border)] bg-[var(--card)] p-7">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400">Trading Vault</p>
        <h1 className="mt-3 text-2xl font-semibold text-white">Create your account</h1>
        <p className="mt-2 text-sm text-[var(--muted)]">Your journal, scans and trading history remain private to your account.</p>
        <form className="mt-7 space-y-4" onSubmit={handleSubmit}>
          <label className="block text-sm text-[var(--muted)]">
            Email
            <input className="mt-2 w-full rounded-lg border border-[var(--border)] bg-black/20 px-3 py-3 text-white outline-none focus:border-cyan-500" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label className="block text-sm text-[var(--muted)]">
            Password
            <input className="mt-2 w-full rounded-lg border border-[var(--border)] bg-black/20 px-3 py-3 text-white outline-none focus:border-cyan-500" type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>
          {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
          {message && <p role="status" className="text-sm text-emerald-400">{message}</p>}
          <button disabled={busy} className="w-full rounded-lg bg-cyan-500 px-4 py-3 font-semibold text-slate-950 disabled:opacity-60">
            {busy ? "Creating account…" : "Create account"}
          </button>
        </form>
        <p className="mt-6 text-sm text-[var(--muted)]">
          Already registered? <Link className="text-cyan-400" href="/login">Sign in</Link>
        </p>
      </section>
    </main>
  );
}
