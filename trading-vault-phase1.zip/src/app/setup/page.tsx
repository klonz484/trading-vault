import Link from "next/link";
import { getSupabasePublicEnv } from "@/lib/supabase/env";

export default function SetupPage() {
  const configured = Boolean(getSupabasePublicEnv());

  return (
    <main className="flex min-h-screen items-center justify-center bg-[var(--background)] px-5 py-12 text-[var(--foreground)]">
      <section className="w-full max-w-xl rounded-2xl border border-[var(--border)] bg-[var(--card)] p-7">
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400">
          Trading Vault · Phase 1
        </p>
        <h1 className="text-2xl font-semibold text-white">Connect Supabase</h1>
        <p className="mt-3 text-sm leading-6 text-[var(--muted)]">
          Authentication is not available until the public Supabase project
          settings are configured in your local environment.
        </p>
        <div className="mt-6 rounded-xl border border-[var(--border)] p-4">
          <p className="text-sm font-medium text-white">
            {configured ? "Public settings detected" : "Configuration required"}
          </p>
          <p className="mt-2 text-xs text-[var(--muted)]">
            Add NEXT_PUBLIC_SUPABASE_URL and
            NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY to .env.local, then restart
            the development server.
          </p>
        </div>
        <p className="mt-6 text-xs text-[var(--muted)]">
          Keep service-role and secret keys on trusted servers only. Never
          expose them in browser code.
        </p>
        <Link className="mt-6 inline-block text-sm text-cyan-400 hover:text-cyan-300" href="/login">
          Go to sign in
        </Link>
      </section>
    </main>
  );
}
