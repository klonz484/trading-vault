"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setBusy(true);

    try {
      const supabase = createClient();
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) throw signInError;

      const requestedNext = new URLSearchParams(window.location.search).get("next") || "/";
      const safeNext = requestedNext.startsWith("/") && !requestedNext.startsWith("//")
        ? requestedNext
        : "/";
      router.replace(safeNext);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[var(--background)] px-5 py-12 text-[var(--foreground)]">
      <section className="w-full max-w-md rounded-2xl border border-[var(--border)] bg-[var(--card)] p-7">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400">Trading Vault</p>
        <h1 className="mt-3 text-2xl font-semibold text-white">Welcome back</h1>
        <p className="mt-2 text-sm text-[var(--muted)]">Sign in to your private trading workspace.</p>
        <form className="mt-7 space-y-4" onSubmit={handleSubmit}>
          <label className="block text-sm text-[var(--muted)]">
            Email
            <input className="mt-2 w-full rounded-lg border border-[var(--border)] bg-black/20 px-3 py-3 text-white outline-none focus:border-cyan-500" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label className="block text-sm text-[var(--muted)]">
            Password
            <input className="mt-2 w-full rounded-lg border border-[var(--border)] bg-black/20 px-3 py-3 text-white outline-none focus:border-cyan-500" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>
          {error && <p role="alert" className="text-sm text-red-400">{error}</p>}
          <button disabled={busy} className="w-full rounded-lg bg-cyan-500 px-4 py-3 font-semibold text-slate-950 disabled:opacity-60">
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>
        <p className="mt-6 text-sm text-[var(--muted)]">
          New to Trading Vault? <Link className="text-cyan-400" href="/signup">Create an account</Link>
        </p>
      </section>
    </main>
  );
}
