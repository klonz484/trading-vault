# Trading Vault — Phase 1 Supabase foundation

This is a **non-destructive overlay** for the existing Trading Vault Next.js 16 project.
It adds Supabase SSR clients, email/password sign-in and sign-up pages, an auth callback,
a logout route, a setup page, a Next.js 16 `proxy.ts`, and a starter database migration.

## Before extracting

1. In the existing Codespace terminal, confirm you are at the repository root:
   `pwd`
2. Make a backup of the current working tree before overlaying files:
   `git status --short`
   `git diff > /tmp/trading-vault-before-phase1.patch`
3. Do not delete or replace `.env.local`, `package-lock.json`, the Scanner, or the Groq API route.

The ZIP contains only new files. It does not contain `.env.local`, credentials, `package.json`,
or `package-lock.json`.

## Dependencies

The project should already have:
- `@supabase/supabase-js@2.118.0`
- `@supabase/ssr@0.12.7`

If they are not present, install them from the project root:
`npm install @supabase/supabase-js@2.118.0 @supabase/ssr@0.12.7`

## Environment

Create or update `.env.local` yourself. Keep the values private:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Use the project's **publishable** key (or legacy anon key if the dashboard only exposes that).
Never put a `service_role` or secret key in a `NEXT_PUBLIC_` variable or browser code.
Keep your existing `GROQ_API_KEY` and `GROQ_VISION_MODEL` entries unchanged.

Restart the dev server after changing environment variables.

## Database

In Supabase Dashboard → SQL Editor → New query, paste and run:
`supabase/migrations/202611040001_phase1_private_foundation.sql`

The migration creates private per-user tables and a private `chart-images` Storage bucket.
RLS is enabled on each application table. Storage objects must be placed under a first folder
matching the authenticated user's UUID.

## Routes added

- `/login`
- `/signup`
- `/auth/callback`
- `/logout`
- `/setup`

`/setup` is public and explains which public Supabase settings are missing. Protected application
routes redirect to `/login` when Supabase is configured but the visitor is not authenticated.
When Supabase is not configured, protected routes redirect to `/setup`.

## Important scope

This is a Phase 1 foundation, not a complete production release. It does not yet:
- change the existing dashboard/sidebar UI to add account controls;
- create admin role assignment or owner-only shared-brain governance;
- add password reset, MFA, rate limiting, email templates, or production monitoring;
- guarantee that the existing scanner has been functionally tested after auth is enabled.

Test locally before considering deployment. Do not deploy or commit without explicit approval.
