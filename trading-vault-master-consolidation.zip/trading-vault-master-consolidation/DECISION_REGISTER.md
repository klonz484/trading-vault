# Decision Register and Verification Status

## Executive status

- **Decisions 836–1095:** 260 decisions across 13 consecutive 20-decision batches. Each batch was explicitly accepted by the user with “Okay”, “Ok” or equivalent after the Option C recommendations were shown.
- **Decisions 1096–1115:** proposed final-review and closure controls. The user accepted the overall plan to finish at 1115, but did not separately confirm the 20 individual rows. They are therefore **proposed, not recorded as approved**.
- **Decisions 1–835:** earlier planning is supported by a mixture of the foundation ZIP, prior master PDF, conversation summaries and memory records. The full verbatim decision ledger and every original A/B/C option set are not present in the material currently available. Do not claim that every one of these numbers has been independently source-verified.
- Historical Option C summaries are not equivalent to recovered original question wording. Preserve that distinction.

## Earlier confirmed architecture choices

The following are supported by the existing Brain master PDF and foundation package:
- Hybrid Trading Brain and hybrid methodology: ICT + SMC + price action + indicators.
- Manual MT5 execution only; no automated order placement, modification or closing.
- Initial market scope: Forex majors and Gold (`forex_gold`): EURUSD, GBPUSD, USDJPY, USDCHF, USDCAD, AUDUSD, NZDUSD and XAUUSD.
- Hybrid market data: MT5 broker context plus an independent data source.
- Scanner V2 and Brain are independent analytical systems with controlled collaboration.
- Collaborative final analytical view; preserve disagreement and uncertainty.
- Shared Core knowledge plus private trader knowledge.
- Controlled experiments; no automatic promotion of private outcomes into Shared Core.
- Shared Core changes require testing and explicit owner approval.
- Supabase Auth / multi-user direction with email verification and private trader workspaces is supported by later project context; Brain-specific schema and RLS migrations remain unimplemented/unverified.

## Earlier numbered history and evidence quality

| Range / item | Status in available records |
|---|---|
| Brain decisions 1–4 | Option C approved and recorded in foundation docs. |
| Engine 2 market-structure rules | Option C rules approved; see architecture section. |
| 356–362 | Prior conversation summaries say Option C; exact original wording not fully available here. |
| 363–365 | Recorded as Option C in the foundation package. |
| 366–371 | Some prior assistant summaries say Option C, but the source ledger was incomplete; treat as historical summary, not independently verified wording. |
| 372–391 | User explicitly approved all displayed Option C summaries. For 377–391, original question/A/B wording was not recovered. |
| 392–415 | Prior assistant claimed Option C; source transcript not fully available for independent verification. |
| 416–435 | User explicitly approved displayed Option C recommendations; exact full original wording was not all preserved. |
| 436–555 | Earlier assistant summaries claimed Option C, but the original source ledger is incomplete. Do not present as fully verified original records. |
| 556–655 | Option C batches accepted in the planning conversation and carried forward in memory. |
| 656–675 | Recommendations were shown as Option C, but explicit approval is not clearly present in the available record. Mark approval as uncertain. |
| 676–835 | Accepted Option C batches recorded in prior conversation summaries. |
| 836–1095 | Explicitly approved batch-by-batch in the current conversation. |
| 1096–1115 | Proposed closure controls; not individually approved. |

## Confirmed recent batches: 836–1095


### 836–855 — Production Infrastructure, Deployment, Monitoring and Reliability

- **836 — Modular cloud architecture.** Option C — approved.
- **837 — Vercel application hosting.** Option C — approved.
- **838 — Supabase managed backend services.** Option C — approved.
- **839 — Dedicated background workers.** Option C — approved.
- **840 — Separate development, staging and production environments.** Option C — approved.
- **841 — Centralised environment configuration.** Option C — approved.
- **842 — Automated CI/CD pipeline.** Option C — approved.
- **843 — Staged deployment process.** Option C — approved.
- **844 — Versioned database migrations.** Option C — approved.
- **845 — Independent worker services.** Option C — approved.
- **846 — Adaptive resource scaling.** Option C — approved.
- **847 — Resource and cost budgets.** Option C — approved.
- **848 — Service health checks.** Option C — approved.
- **849 — Centralised logs, metrics and traces.** Option C — approved.
- **850 — Structured error management.** Option C — approved.
- **851 — Severity-based operational alerts.** Option C — approved.
- **852 — Automated backups.** Option C — approved.
- **853 — Disaster recovery procedures.** Option C — approved.
- **854 — Incident response process.** Option C — approved.
- **855 — Operational dashboard.** Option C — approved.

### 856–875 — Platform Administration, User Management, Billing Readiness and Commercial Governance

- **856 — Centralised owner administration with role-based access.** Option C — approved.
- **857 — Complete user lifecycle management.** Option C — approved.
- **858 — Email verification and controlled account recovery.** Option C — approved.
- **859 — Account states: active, suspended, restricted and deleted.** Option C — approved.
- **860 — Fine-grained least-privilege permissions.** Option C — approved.
- **861 — Auditable administrative actions.** Option C — approved.
- **862 — Centralised version-controlled platform settings.** Option C — approved.
- **863 — Feature flags and controlled rollout.** Option C — approved.
- **864 — Guided registration and onboarding.** Option C — approved.
- **865 — Private user preferences.** Option C — approved.
- **866 — Structured support requests and resolution tracking.** Option C — approved.
- **867 — Targeted in-app announcements.** Option C — approved.
- **868 — Privacy-aware usage analytics.** Option C — approved.
- **869 — Subscription-ready architecture without immediate payment activation.** Option C — approved.
- **870 — Configurable future subscription tiers.** Option C — approved.
- **871 — Configurable scan, AI and storage limits.** Option C — approved.
- **872 — Modular payment-provider integration.** Option C — approved.
- **873 — Server-side entitlement enforcement.** Option C — approved.
- **874 — Commercial and subscription reporting.** Option C — approved.
- **875 — Owner-controlled pricing and subscription governance.** Option C — approved.

### 876–895 — User Experience, Dashboard Intelligence and Personalisation

- **876 — Unified experience across platform modules.** Option C — approved.
- **877 — Modular configurable dashboard widgets.** Option C — approved.
- **878 — Per-user saved dashboard layouts.** Option C — approved.
- **879 — Consistent navigation and contextual shortcuts.** Option C — approved.
- **880 — Mobile-first responsive design.** Option C — approved.
- **881 — Expanded desktop workspace.** Option C — approved.
- **882 — Dark and light themes.** Option C — approved.
- **883 — Adjustable compact and detailed views.** Option C — approved.
- **884 — Customisable multi-panel trading workspace.** Option C — approved.
- **885 — Unified instrument selector.** Option C — approved.
- **886 — Consistent timeframe controls.** Option C — approved.
- **887 — Charts, tables and structured evidence views.** Option C — approved.
- **888 — Expandable reasoning with evidence and uncertainty.** Option C — approved.
- **889 — User-configurable notification categories.** Option C — approved.
- **890 — Severity-based notification grouping.** Option C — approved.
- **891 — Global search across permitted records.** Option C — approved.
- **892 — Unified activity timeline.** Option C — approved.
- **893 — Keyboard, screen-reader and contrast accessibility.** Option C — approved.
- **894 — Progressive loading and processing states.** Option C — approved.
- **895 — Shared design system and reusable UI components.** Option C — approved.

### 896–915 — Chart Visualisation, Interactive Analysis and Trading Workspace Tools

- **896 — Unified interactive charting engine.** Option C — approved.
- **897 — Candles, volume and supported overlays.** Option C — approved.
- **898 — Synchronized multi-timeframe controls.** Option C — approved.
- **899 — Configurable multi-chart workspace.** Option C — approved.
- **900 — Interactive trendlines, zones and structural markings.** Option C — approved.
- **901 — BOS, CHoCH, MSS and swing labels.** Option C — approved.
- **902 — EQH, EQL, liquidity pools and sweep markers.** Option C — approved.
- **903 — FVG, liquidity void and mitigation overlays.** Option C — approved.
- **904 — Order block, breaker and mitigation overlays.** Option C — approved.
- **905 — Premium/discount and dealing-range visualisation.** Option C — approved.
- **906 — Configurable trading-session overlays.** Option C — approved.
- **907 — Higher-timeframe levels on lower-timeframe charts.** Option C — approved.
- **908 — Selectable evidence with explanations.** Option C — approved.
- **909 — Historical market-data and event replay.** Option C — approved.
- **910 — Timestamped event timeline with provenance.** Option C — approved.
- **911 — Instrument, timeframe and analysis comparison.** Option C — approved.
- **912 — Screenshot comparison against verified market data.** Option C — approved.
- **913 — Saved layouts, drawings and viewing preferences.** Option C — approved.
- **914 — Export charts, annotations and reports.** Option C — approved.
- **915 — Efficient rendering for large datasets and multiple charts.** Option C — approved.

### 916–935 — Alerts, Market Monitoring, Opportunity Detection and Event Intelligence

- **916 — Continuous event-driven monitoring plus scheduled checks.** Option C — approved.
- **917 — Monitoring of enabled Forex pairs and Gold.** Option C — approved.
- **918 — Configurable monitoring across supported timeframes.** Option C — approved.
- **919 — Multi-factor opportunity discovery.** Option C — approved.
- **920 — Detection of developing, confirmed and invalidated setups.** Option C — approved.
- **921 — Monitoring structure breaks, sweeps, displacement and volatility.** Option C — approved.
- **922 — Important liquidity-level and sweep alerts.** Option C — approved.
- **923 — Session opening, closing and transition alerts.** Option C — approved.
- **924 — Economic calendar with impact filters.** Option C — approved.
- **925 — Configurable pre-event and post-event risk windows.** Option C — approved.
- **926 — User-defined price and price-zone alerts.** Option C — approved.
- **927 — Significant BOS, CHoCH and MSS alerts.** Option C — approved.
- **928 — Evidence-threshold setup alerts.** Option C — approved.
- **929 — Alert evidence strength and uncertainty.** Option C — approved.
- **930 — Urgency- and relevance-based alert ranking.** Option C — approved.
- **931 — Deduplication while retaining meaningful updates.** Option C — approved.
- **932 — Alert lifecycle states and acknowledgement.** Option C — approved.
- **933 — In-app alerts first with optional external channels.** Option C — approved.
- **934 — Retry and delivery-status tracking.** Option C — approved.
- **935 — User-configurable instruments, events, thresholds and quiet hours.** Option C — approved.

### 936–955 — Trading Strategies, Setup Validation, Backtesting and Strategy Intelligence

- **936 — Modular independent specialist strategies.** Option C — approved.
- **937 — ICT, SMC, price-action and indicator-assisted catalogue.** Option C — approved.
- **938 — Versioned configurable strategy parameters.** Option C — approved.
- **939 — Independent strategy activation controls.** Option C — approved.
- **940 — Strategy suitability by market regime.** Option C — approved.
- **941 — Explicit mandatory and optional setup conditions.** Option C — approved.
- **942 — Evidence-weighted confluence scoring.** Option C — approved.
- **943 — Multi-stage validation with pass/fail reasons.** Option C — approved.
- **944 — Strategy-specific entry models and confirmation.** Option C — approved.
- **945 — Structural invalidation stop-loss methodology.** Option C — approved.
- **946 — Liquidity-, structure- and reward-based targets.** Option C — approved.
- **947 — Manual trade-management plans.** Option C — approved.
- **948 — Preservation of competing strategy evidence.** Option C — approved.
- **949 — Historical candle and tick replay where data permits.** Option C — approved.
- **950 — Spread, commission, slippage and execution assumptions.** Option C — approved.
- **951 — Expectancy, win rate, profit factor, drawdown and R metrics.** Option C — approved.
- **952 — In-sample, out-of-sample and walk-forward validation.** Option C — approved.
- **953 — Parameter sensitivity and regime robustness testing.** Option C — approved.
- **954 — Consistent strategy comparison datasets and metrics.** Option C — approved.
- **955 — Evidence and owner approval before strategy promotion.** Option C — approved.

### 956–975 — Trading Psychology, Behavioural Intelligence, Journal and Performance Coaching

- **956 — Dedicated behavioural intelligence module.** Option C — approved.
- **957 — Behaviour tracking from journal and user feedback.** Option C — approved.
- **958 — Optional pre-trade and post-trade emotional check-ins.** Option C — approved.
- **959 — Adherence to trader-defined rules.** Option C — approved.
- **960 — Excessive frequency and low-quality entry detection.** Option C — approved.
- **961 — Patterns consistent with revenge trading.** Option C — approved.
- **962 — Repeated risk-limit and position-sizing violations.** Option C — approved.
- **963 — Decision quality separated from trade outcome.** Option C — approved.
- **964 — Configurable mistake taxonomy.** Option C — approved.
- **965 — Structured journal plus free-form notes.** Option C — approved.
- **966 — Link scans, setups, conditions and trades where available.** Option C — approved.
- **967 — Screenshots, annotations and supporting evidence.** Option C — approved.
- **968 — Performance by strategy, instrument, timeframe and session.** Option C — approved.
- **969 — Behaviour/performance correlation analysis.** Option C — approved.
- **970 — Evidence-based personalised improvement suggestions.** Option C — approved.
- **971 — Measurable learning goals and practice exercises.** Option C — approved.
- **972 — Explainable rule-adherence scoring.** Option C — approved.
- **973 — Behavioural and performance progress tracking.** Option C — approved.
- **974 — Private psychology and journal records.** Option C — approved.
- **975 — Advisory coaching with trader judgement.** Option C — approved.

### 976–995 — Advanced Risk Intelligence, Portfolio Exposure and Capital Protection

- **976 — Centralised portfolio-wide risk intelligence.** Option C — approved.
- **977 — Multiple account profiles per trader.** Option C — approved.
- **978 — Configurable risk rules per account.** Option C — approved.
- **979 — Instrument-aware dynamic position sizing.** Option C — approved.
- **980 — Open and pending exposure calculations.** Option C — approved.
- **981 — Dynamic Forex and Gold correlation.** Option C — approved.
- **982 — Currency concentration monitoring.** Option C — approved.
- **983 — Aggregate risk across correlated positions.** Option C — approved.
- **984 — Daily, weekly and total drawdown limits.** Option C — approved.
- **985 — Consecutive-loss detection and risk-reduction advice.** Option C — approved.
- **986 — Volatility-aware risk warnings.** Option C — approved.
- **987 — Spread and transaction-cost checks.** Option C — approved.
- **988 — Expected and observed slippage modelling.** Option C — approved.
- **989 — High-impact news exposure warnings.** Option C — approved.
- **990 — Missing, invalid or weak stop-loss detection.** Option C — approved.
- **991 — Net reward-to-risk after costs.** Option C — approved.
- **992 — Adverse-movement and portfolio stress simulation.** Option C — approved.
- **993 — Protective recommendations near configured limits.** Option C — approved.
- **994 — Explainable risk warnings and calculations.** Option C — approved.
- **995 — Advisory-only risk governance; no automated execution.** Option C — approved.

### 996–1015 — Advanced Market Intelligence, Macro Context and Cross-Market Analysis

- **996 — Dedicated macro and cross-market intelligence layer.** Option C — approved.
- **997 — Economic calendar with event metadata.** Option C — approved.
- **998 — Multi-source news with source reliability scoring.** Option C — approved.
- **999 — AI-assisted impact analysis grounded in verified events.** Option C — approved.
- **1000 — Inflation, employment, growth and central-bank indicators.** Option C — approved.
- **1001 — Rate decisions, policy statements and guidance.** Option C — approved.
- **1002 — Compare monetary-policy expectations across currencies.** Option C — approved.
- **1003 — Multi-factor relative currency strength.** Option C — approved.
- **1004 — Relationships across Forex, Gold and available markets.** Option C — approved.
- **1005 — Dedicated XAUUSD macro, dollar and real-yield context.** Option C — approved.
- **1006 — Broad USD strength and relevant drivers.** Option C — approved.
- **1007 — Bond-yield data with freshness indicators.** Option C — approved.
- **1008 — Risk-on, risk-off and transitional sentiment classification.** Option C — approved.
- **1009 — Relevant geopolitical developments and uncertainty.** Option C — approved.
- **1010 — Actual-versus-expectation event surprise analysis.** Option C — approved.
- **1011 — Macro context separate from technical engine authority.** Option C — approved.
- **1012 — Preserve macro/technical disagreement.** Option C — approved.
- **1013 — Longer-term market-regime changes and transitions.** Option C — approved.
- **1014 — Source timestamps, provenance, freshness and disagreement.** Option C — approved.
- **1015 — Explain macro influence or non-influence on conclusions.** Option C — approved.

### 1016–1035 — Advanced AI Reasoning, Multi-Agent Collaboration and Decision Governance

- **1016 — Multi-agent architecture with central reasoning orchestrator.** Option C — approved.
- **1017 — Specialist agents for structure, liquidity, strategy, risk, macro and psychology.** Option C — approved.
- **1018 — Independent analysis before collaboration.** Option C — approved.
- **1019 — Structured versioned messages with evidence references.** Option C — approved.
- **1020 — Parallel analysis followed by controlled synthesis.** Option C — approved.
- **1021 — Verified data and deterministic calculations take priority.** Option C — approved.
- **1022 — AI interprets; deterministic engines handle critical calculations.** Option C — approved.
- **1023 — Preserve contradictions and explain causes.** Option C — approved.
- **1024 — Weighted collaboration without forced consensus.** Option C — approved.
- **1025 — Calibrated confidence based on evidence and agreement.** Option C — approved.
- **1026 — Explicit missing, weak and contradictory evidence.** Option C — approved.
- **1027 — Auditable inputs, agent findings and synthesis trace.** Option C — approved.
- **1028 — Relevant memory with shared/private boundaries.** Option C — approved.
- **1029 — Task-based routing across approved AI providers.** Option C — approved.
- **1030 — Provider fallback with output validation.** Option C — approved.
- **1031 — Evidence-grounded hallucination controls.** Option C — approved.
- **1032 — Collaborative conclusion with transparent limits.** Option C — approved.
- **1033 — Trader retains final responsibility.** Option C — approved.
- **1034 — Benchmarks for accuracy, consistency, latency and cost.** Option C — approved.
- **1035 — Versioned prompts, model configurations, approvals and rollback.** Option C — approved.

### 1036–1055 — Data Governance, Privacy, Compliance Readiness and Platform Trust

- **1036 — Centralised data governance.** Option C — approved.
- **1037 — Public/shared/private/confidential/operational data classification.** Option C — approved.
- **1038 — User ownership of private trading records.** Option C — approved.
- **1039 — Least-privilege server-side data access.** Option C — approved.
- **1040 — Strong tenant isolation with database-level enforcement.** Option C — approved.
- **1041 — Explicit Shared Core/private Trader Brain separation.** Option C — approved.
- **1042 — Granular consent for optional processing and integrations.** Option C — approved.
- **1043 — Purpose-limited data collection.** Option C — approved.
- **1044 — Retention policies by data category.** Option C — approved.
- **1045 — Controlled deletion with dependency checks.** Option C — approved.
- **1046 — User export in documented formats.** Option C — approved.
- **1047 — Encryption in transit and at rest.** Option C — approved.
- **1048 — Centralised secret storage, rotation and audit.** Option C — approved.
- **1049 — Unusual-access and privacy-violation monitoring.** Option C — approved.
- **1050 — Tamper-resistant sensitive-operation audit trails.** Option C — approved.
- **1051 — Documented controls without false compliance claims.** Option C — approved.
- **1052 — Periodic review of relevant regulatory changes.** Option C — approved.
- **1053 — Transparency on data use, AI processing and limitations.** Option C — approved.
- **1054 — Service status, security and incident transparency.** Option C — approved.
- **1055 — Owner-led periodic governance review.** Option C — approved.

### 1056–1075 — Advanced Testing, Validation, Simulation and Quality Assurance

- **1056 — Centralised quality framework.** Option C — approved.
- **1057 — Automated testing in development pipeline.** Option C — approved.
- **1058 — Unit tests for calculations, rules and engines.** Option C — approved.
- **1059 — Integration tests for module communication.** Option C — approved.
- **1060 — End-to-end user workflow tests.** Option C — approved.
- **1061 — Historical candle and market-condition replay.** Option C — approved.
- **1062 — Tick-level replay where reliable data exists.** Option C — approved.
- **1063 — Versioned normal, unusual and extreme scenario library.** Option C — approved.
- **1064 — Edge cases: missing candles, gaps, spreads and provider conflicts.** Option C — approved.
- **1065 — Data accuracy, completeness, timestamp and consistency tests.** Option C — approved.
- **1066 — Strategy testing across market regimes.** Option C — approved.
- **1067 — AI reasoning, grounding and consistency evaluation.** Option C — approved.
- **1068 — Independent risk-calculation verification.** Option C — approved.
- **1069 — Automated vulnerability checks and periodic security assessments.** Option C — approved.
- **1070 — Latency, throughput and resource performance tests.** Option C — approved.
- **1071 — Concurrent-user and high-volume event load tests.** Option C — approved.
- **1072 — Regression testing.** Option C — approved.
- **1073 — Documented release quality gates.** Option C — approved.
- **1074 — Severity, ownership and regression defect tracking.** Option C — approved.
- **1075 — Unified quality dashboard with test evidence.** Option C — approved.

### 1076–1095 — Product Intelligence, Platform Growth and Future Expansion

- **1076 — Modular platform for controlled expansion.** Option C — approved.
- **1077 — Extensible instrument registry beyond initial Forex and Gold.** Option C — approved.
- **1078 — Future indices, commodities and other markets.** Option C — approved.
- **1079 — Multi-language architecture with English initially.** Option C — approved.
- **1080 — Configurable timezone, date, number and currency formats.** Option C — approved.
- **1081 — User groups without private-data exposure.** Option C — approved.
- **1082 — Future subscription tiers and optional add-ons.** Option C — approved.
- **1083 — Catalogue of approved platform capabilities.** Option C — approved.
- **1084 — Versioned third-party integration framework.** Option C — approved.
- **1085 — Documented APIs for authorised external applications.** Option C — approved.
- **1086 — Stable extension interfaces for specialist engines.** Option C — approved.
- **1087 — Private user-configured strategy variations.** Option C — approved.
- **1088 — Configurable indicators and analytical overlays.** Option C — approved.
- **1089 — Reusable dashboard templates and personal layouts.** Option C — approved.
- **1090 — Controlled addition of trading concepts and research.** Option C — approved.
- **1091 — Optional community readiness with privacy safeguards.** Option C — approved.
- **1092 — Optional learning resources and guided education.** Option C — approved.
- **1093 — Privacy-aware feature adoption and usability analytics.** Option C — approved.
- **1094 — Testing, security review and owner approval for major expansion.** Option C — approved.
- **1095 — Versioned interfaces and migration strategies.** Option C — approved.

## Proposed closure controls: 1096–1115 (not individually approved)

1. End-to-end architecture validation.
2. Consistency review across approved decisions.
3. Functional and technical completeness check.
4. Dependency mapping between modules and services.
5. Confirmation of system boundaries and component responsibilities.
6. Technology choice validation against the approved architecture.
7. Database, relationship and RLS readiness review.
8. API contracts, versioning, authentication and error-standard review.
9. Market-data provider, quality, fallback and MT5 read-only review.
10. AI agent, provider routing, evaluation and governance review.
11. Risk calculation and capital-protection review.
12. Authentication, authorisation, isolation and secret-management review.
13. Measurable performance and reliability targets.
14. Test coverage and acceptance criteria.
15. Development/staging/production and rollback requirements.
16. Monitoring, backups and incident readiness.
17. Complete versioned technical documentation.
18. Ordered implementation roadmap and dependencies.
19. Acceptance gates and owner approval controls.
20. Specification baseline freeze with future changes tracked separately.

These 20 items describe the proposed closure review, not a verified approval of every row.
