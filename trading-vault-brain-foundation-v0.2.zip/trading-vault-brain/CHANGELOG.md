# Changelog

## 0.2.0

### Fixed
- The TypeScript types (camelCase) and the JSON schema (snake_case) could not describe the same object, and the schema allowed results the types forbid. Added explicit mappers (`core/wire.ts`) and aligned the schema's required fields with the types.
- Engine result evidence items were unvalidated (`type: object`). They now have a real schema (id, description, UTC time, timeframe, source).
- Timestamps only needed to look like dates. They must now be UTC ending in `Z` and a real calendar instant (`Date.parse` alone accepts 2026-02-31).
- Engine README titles ("Ict", "Smc") and boilerplate corrected.
- The original orchestrator ran every engine at once regardless of dependencies, ignored hangs, and reported failures only as warning text.

### Added
- `core/validate.ts`: validators for engine output, stamped results and analysis requests, enforcing the approved safety rules (unavailable means no direction and no confidence; available results carry provenance; confirmed needs a closed candle; unique evidence ids).
- `core/orchestrator.ts`: dependency layers (`dependsOn` / `softDependsOn`), required per-engine timeout and cancellation, failure isolation, explicit `unavailable` results, identity stamping, whole-output rejection for invalid findings, deterministic ordering, per-engine run records.
- Result fields `request_id`, `engine_version` and `candle`; `message_kind: "evidence"` and required `provenance` on Scanner messages.
- `configuration/market-structure.approved.json`: only the Engine 2 values already in `APPROVED_DECISIONS.md`; unapproved thresholds are `null`.
- 57 tests with no added dependencies: contracts against the real schema files, validator, orchestrator, and safety (no order placement, no secrets, no Scanner/host imports in `core/`, governance flags). `tsconfig.json` for a strict typecheck.
- Contract versioning rules, orchestration rules and a suggested decision order for the open items.

### Changed (breaking, no consumers yet)
- `SpecialistEngine.analyze` takes `(request, context)` and returns `EngineFinding[]` instead of `EngineResult[]`.
- `runSpecialists` requires an `options` argument with `engineTimeoutMs`.

### Deliberately not done
- No decision was invented. Decision 366, numeric thresholds, provider choices, the latency budget and the exact degraded-operation policy (decision 364) are still open.
- No engine logic, database migration or Scanner integration was added.
