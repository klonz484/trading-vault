# Risk Engine

Status: interface placeholder — not production logic.

Responsibilities, inputs, outputs, validation and dependencies are defined in
`documentation/ENGINE_SPECIFICATIONS.md`.

Implementation requirements:
- Implement `SpecialistEngine` from `core/engine-interface.ts` and return `EngineFinding[]`; the orchestrator stamps engine id/version and request id.
- Declare upstream engines in `dependsOn` (hard: engine is skipped and reported `unavailable` if they are) or `softDependsOn` (engine still runs and handles the gap).
- Use only the `context.upstream` results you declared, and stop work when `context.signal` aborts.
- Preserve evidence provenance and UTC timestamps.
- Return explicit event state; never silently confirm provisional events.
- Include contrary evidence and warnings where relevant.
- Do not place, modify or close trades.
- Report missing data as `unavailable` (direction `unknown`, confidence `null`), never as a neutral or negative finding.
- Add unit tests and replay fixtures before enabling this engine.
