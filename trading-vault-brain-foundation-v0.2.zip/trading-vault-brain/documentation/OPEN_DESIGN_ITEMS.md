# Open Design Items — Do Not Guess

These items must be decided or explicitly assigned a safe default before production implementation:

1. Independent market-data provider and exact MT5 read-only integration.
2. Hosting topology, ingestion cadence, retention and historical correction policy.
3. Engine-by-engine JSON schemas, event names and IDs. (Partly addressed: the shared result envelope, versioning rules and failure semantics now exist; each engine's own evidence payload and event names are still open.)
4. Exact ICT/SMC definitions and numeric thresholds not already approved.
5. Strategy catalogue, entry/exit logic, scoring and backtest/replay acceptance criteria.
6. Risk sizing: account currency, pip/point values, contract sizes, broker symbol suffixes and assumptions.
7. AI provider/model, fallback, latency/cost budget and deterministic boundaries.
8. News/calendar provider, event mapping and blackout policy.
9. Supabase schema, RLS policies, storage buckets, retention/export/deletion and audit model.
10. Monitoring, dashboards, alert routing and degraded-mode policy.
11. Experiment sample sizes, out-of-sample rules, fees/spread/slippage and promotion gates.
12. Security review, test coverage, performance targets and rollback plan.

Decision 366 is next in the overall numbered ledger, but its exact wording/options are not available in this package source. Recover it from the original planning conversation before recording a selection.

## Suggested order for deciding these (a proposal, not a decision)

Chosen by what blocks the first working engine, so nothing has to be guessed:

1. Item 7 (latency budget, AI provider boundary) and item 10 (degraded mode): the orchestrator needs `engineTimeoutMs`, and decision 364 must be recovered before degraded behaviour is finalised.
2. Item 1 (market-data provider, MT5 read-only integration): blocks Market Data, and everything downstream of it.
3. Item 4 (ICT/SMC definitions and thresholds): start with the Market Structure displacement thresholds, which are `null` in `configuration/market-structure.approved.json`.
4. Item 9 (Supabase schema, RLS, audit): needed before any private record is stored.
5. Items 5, 6, 8, 11, 12 once an engine produces real output to test against.

