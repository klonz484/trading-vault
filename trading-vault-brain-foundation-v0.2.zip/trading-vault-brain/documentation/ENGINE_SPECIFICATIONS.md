# Specialist Engine Specifications

This is an interface-level foundation. Numeric thresholds, strategy rules, provider selection and full acceptance criteria remain open unless explicitly approved below.

| Engine | Responsibility | Main inputs | Expected outputs |
|---|---|---|---|
| Market Data | Normalize broker and independent-provider data | candles, ticks, symbol metadata, source status | normalized observations, provenance, gaps, conflicts |
| Market Context | Classify regime and timeframe alignment | validated candles, structure, volatility, sessions, events | trend/range/transition context and warnings |
| Market Structure | Swings, BOS, CHoCH/MSS, ranges, invalidation | validated multi-timeframe candles | structural map, levels, event state, evidence |
| Liquidity | Pools, equal highs/lows, sweeps, objectives | swings, session extremes, ranges | liquidity map, sweep evidence, objectives |
| ICT | Evaluate ICT concepts | structure, liquidity, displacement, sessions | concept observations with evidence and invalidation |
| SMC | OB, FVG, breaker, mitigation/rejection zones | structure, displacement, candle sequences | candidate/validated zones and lifecycle |
| Price Action | Rejection, acceptance, momentum, exhaustion | candles, levels, context | price-action evidence and follow-through |
| Indicators | Traditional technical measures | validated candles and settings | indicator values/states; supporting evidence |
| Sessions | Session windows and ranges | UTC time, calendars, instrument hours | session labels, opens/closes, range extremes |
| News | Scheduled event risk | calendar feed, impact, currency mapping | event windows, affected instruments, freshness |
| Strategy | Apply versioned setup rules | context, specialist evidence, filters, risk | setup candidates, rule trace, invalidation |
| Confluence | Combine independent evidence | engine findings, provenance, quality | alignment, conflicts, ranked evidence |
| Risk | Calculate transparent risk estimates | user inputs, contract specs, stop/target | risk amount, sizing estimate, warnings |
| Reasoning | Explain combined evidence | all engine outputs and user request | conclusion, rationale, uncertainty, conditions |
| Memory | Retrieve governed shared/private knowledge | approved rules, private user history | versioned knowledge and private context |
| Learning | Run reproducible experiments | hypotheses, data, strategy versions | experiment results and candidate proposals |
| Validation | Measure strategy and engine quality | replay results, journal, versions | validation metrics, limitations, QA report |

## Common requirements

- Preserve provenance and timestamps.
- Distinguish facts, hypotheses and inferences.
- Preserve contrary evidence.
- Distinguish missing data from negative evidence.
- Never silently promote provisional events to confirmed.
- Use versioned rules and reproducible test cases.
- Never imply guaranteed trading outcomes.
