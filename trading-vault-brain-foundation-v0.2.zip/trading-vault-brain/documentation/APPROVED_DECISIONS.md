# Approved Brain Decisions

## Product and architecture
- Hybrid Brain and hybrid methodology.
- Manual MT5 execution only.
- Initial coverage: Forex majors and Gold.
- Hybrid market data sourcing.
- Brain and Scanner are independent but collaborate through controlled interfaces.
- Final analysis is collaborative.
- Shared Core plus private trader knowledge.
- Learning through controlled experiments.
- Shared Core improvements require testing and owner approval.

## Brain decisions 1–4 — Option C
1. Activation: user-triggered analysis plus automatic market-event monitoring.
2. Presentation: detailed explanations plus structured results.
3. Developing structures: live provisional tracking plus closed-candle confirmation.
4. Engine disagreement: compare evidence, explain conflicts, collaborate on a conclusion and show uncertainty.

## Engine 2 — Market Structure rules already approved
- Internal swings: 2-left / 2-right.
- External swings: 5-left / 5-right.
- External structure defines primary trend; internal shifts do not silently override it.
- Wick penetration is a break attempt / possible sweep; candle close beyond a level confirms BOS under the selected rule.
- Staged shift: potential shift → closed-candle CHoCH → MSS supported by displacement and configured evidence → external reversal.
- Retest is not mandatory for initial MSS. Successful retest upgrades evidence; failed retest adds contrary evidence.
- Displacement considers body/range relative to ATR, close location, sequence, speed, broken level and follow-through. Volume is supplementary if available.
- Forming-candle events remain provisional and update continuously. Confirmed structural events require closed candles and confirmation rules. No silent provisional-to-confirmed transition.

## Later numbered decision ledger
- Decisions 363–365 were recorded as Option C:
  - 363: Hybrid Engine Orchestration
  - 364: Intelligent Degraded Operation
  - 365: Adaptive Communication Priority
- Decision 366 was identified as the next overall planning item. Its exact wording/options must be recovered before implementation; do not invent it.
