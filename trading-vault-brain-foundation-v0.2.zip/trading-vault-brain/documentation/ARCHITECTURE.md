# Trading Vault Brain Architecture

## Approved direction

| Area | Decision |
|---|---|
| Brain type | Hybrid Brain |
| Methodology | Hybrid: ICT + SMC + price action + indicators |
| Execution | Manual MT5 only; no automatic order execution |
| Market scope | Forex majors + Gold (`forex_gold`) |
| Data sourcing | Hybrid: MT5 broker feed + independent provider |
| Scanner relationship | Independent pipelines with controlled collaboration |
| Final analytical authority | Collaborative, with conflicts and uncertainty visible |
| Knowledge | Shared Core + private trader knowledge |
| Learning | Controlled experiments |
| Shared Core changes | Testing and owner approval required |

## Processing flow

Market data → data validation → market context → specialist engines → evidence aggregation → confluence/conflict analysis → central reasoning → risk/quality validation → structured analysis → trader review → manual MT5 execution.

A separate learning path records private outcomes, runs controlled experiments, evaluates evidence and proposes candidate improvements. It cannot directly mutate Shared Core knowledge.

## Separation principles

1. The Brain and Scanner keep separate analytical pipelines and independent conclusions.
2. They exchange structured, versioned evidence only.
3. Each conclusion retains source, timestamp, timeframe, provenance and uncertainty.
4. Imported findings are evidence, not commands.
5. A collaborative final view explains agreement, disagreement and missing evidence.
6. User data is tenant-isolated. Shared Core content is centrally governed.

## Specialist engines

- Market Data
- Market Context / Regime
- Market Structure
- Liquidity
- ICT
- SMC
- Price Action
- Indicators
- Sessions
- News / Economic Calendar
- Strategy
- Confluence
- Risk
- AI Reasoning / Orchestration
- Memory / Knowledge
- Experimental Learning
- Performance / Validation

Each engine must implement a common input/output envelope and must report `provisional`, `confirmed`, `invalidated`, or `unavailable` where applicable.

## Result envelope and invariants

Engines return `EngineFinding` objects. The orchestrator stamps `schemaVersion`, `requestId`, `engineId` and `engineVersion`, so an engine cannot misreport its own identity. The same fields exist on the wire (`contracts/engine-result.schema.json`, snake_case); `core/wire.ts` is the only place the two meet.

These rules are enforced in code (`core/validate.ts`), in the JSON schema, and by tests:

1. Every timestamp is UTC and ends in `Z`; every timeframe is one of `M1 M5 M15 M30 H1 H4 D1 W1`.
2. `confidence` is `null` or a number from 0 to 1.
3. An `unavailable` result makes no directional claim: direction `unknown`, confidence `null`. Missing data is never negative evidence.
4. An available result (`provisional`, `confirmed`, `invalidated`) lists at least one source in `sourceRefs`; every evidence item names its `source`.
5. A `confirmed` result whose `candle` is present must have `candle.closed = true`. Forming-candle results stay `provisional`.
6. Evidence ids are unique within a result (across evidence and contrary evidence). The JSON schema cannot express this; the validator does.
7. Contrary evidence has its own required field and is never merged away.

## Orchestration rules

`runSpecialists(request, engines, { engineTimeoutMs })` in `core/orchestrator.ts`:

- Runs engines in dependency layers (`dependsOn`, `softDependsOn`); engines in one layer run in parallel. Cycles, unknown ids and duplicate ids are configuration errors.
- Every engine gets a timeout and an `AbortSignal`. A throw, a hang, a cancellation or invalid output becomes explicit `unavailable` results plus a warning and a run record. It never aborts the other engines.
- A hard dependency with no usable result causes the dependent engine to be skipped (fail closed) and reported `unavailable`. A soft dependency gap lets the engine run and handle it (degraded operation).
- Output that answers a different instrument or timeframe than requested, or that breaks an invariant, is rejected whole.
- Results are ordered by engine registration order, never by completion time.

The timeout is a required option with no default because the latency budget is an open design item.

Not built yet: retries, priority scheduling, metrics export, and the full degraded-operation policy (decision 364 wording must be recovered; see `OPEN_DESIGN_ITEMS.md`).

## Contract versioning

- The foundation had no consumers, so `1.0.0` was corrected in place (the previous schema and TypeScript types disagreed on field names and required fields).
- From now on: adding an optional field is a minor bump; adding a required field, renaming, or tightening a rule is a major bump. Update `SCHEMA_VERSION`, both schemas and the tests together; `tests/contracts.test.ts` fails if they drift.

