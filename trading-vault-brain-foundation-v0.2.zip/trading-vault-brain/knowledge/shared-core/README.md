# Shared Core Knowledge

Contains centrally approved, versioned methodology and reference knowledge only.
Every release must have an owner approval record and validation evidence.
Private trader journals, scans, account details and experiment records do not
belong here.
