# Private Trader Knowledge

Runtime records must be scoped to the authenticated trader identity and protected
by database authorization/RLS. This directory is a design boundary, not a place
to commit real user records or secrets.
