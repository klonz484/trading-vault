import type { AnalysisRequest, EngineFinding, EngineResult } from "./types";

/** Passed to every engine call. */
export interface EngineContext {
  /** Aborted on timeout or when the whole analysis is cancelled. Engines should stop work. */
  readonly signal: AbortSignal;
  /**
   * Results of the engines this engine declared in `dependsOn` / `softDependsOn`,
   * keyed by engine id. Engines see nothing they did not declare.
   */
  readonly upstream: ReadonlyMap<string, readonly EngineResult[]>;
}

/**
 * Every specialist engine must be independently testable and return
 * provenance-rich evidence. Implementations must not execute trades.
 */
export interface SpecialistEngine {
  readonly id: string;
  readonly version: string;
  /**
   * Hard dependencies. If any of these produced no usable (non-`unavailable`)
   * result, this engine is not run and is reported as `unavailable`
   * (fail closed: missing data is never treated as negative evidence).
   */
  readonly dependsOn?: readonly string[];
  /**
   * Soft dependencies. Run order is respected, but this engine still runs when
   * they are unavailable and must handle the missing input itself (degraded
   * operation).
   */
  readonly softDependsOn?: readonly string[];
  /** `context` may be omitted from an implementation's signature if unused. */
  analyze(request: AnalysisRequest, context: EngineContext): Promise<EngineFinding[]>;
}
