/**
 * Shared types for Trading Vault Brain.
 * This package intentionally has no runtime dependencies yet.
 *
 * The constants below are the single source of truth for the enumerations.
 * `tests/contracts.test.ts` fails if they drift from the JSON contracts or
 * from `configuration/instruments.json`.
 */

export const SCHEMA_VERSION = "1.0.0" as const;

export const TIMEFRAMES = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1"] as const;
export type Timeframe = (typeof TIMEFRAMES)[number];

export const EVENT_STATES = ["provisional", "confirmed", "invalidated", "unavailable"] as const;
export type EventState = (typeof EVENT_STATES)[number];

export const DIRECTIONS = ["bullish", "bearish", "neutral", "unknown"] as const;
export type Direction = (typeof DIRECTIONS)[number];

export const ANALYSIS_MODES = ["user_triggered", "market_event"] as const;
export type AnalysisMode = (typeof ANALYSIS_MODES)[number];

export interface EvidenceItem {
  id: string;
  description: string;
  /** UTC ISO-8601 timestamp ending in `Z`. */
  observedAt: string;
  timeframe: Timeframe;
  source: string;
  weight?: number;
  metadata?: Record<string, unknown>;
}

/** The candle a result is "as of". Confirmed results require `closed: true`. */
export interface CandleBasis {
  /** UTC open time of the candle. */
  openTime: string;
  closed: boolean;
}

/**
 * What an engine produces. Identity fields (engine id/version, request id,
 * schema version) are deliberately absent: the orchestrator stamps them so an
 * engine can never misreport who produced a result.
 */
export interface EngineFinding {
  instrument: string;
  timeframe: Timeframe;
  observedAt: string;
  state: EventState;
  direction: Direction;
  /** 0..1, or null when the engine does not produce a confidence. */
  confidence: number | null;
  /** Explicit `null` for engines/results that are not candle-based. */
  candle: CandleBasis | null;
  evidence: EvidenceItem[];
  contraryEvidence: EvidenceItem[];
  invalidation: Record<string, unknown> | null;
  sourceRefs: string[];
  warnings: string[];
}

/** A finding plus the identity fields stamped by the orchestrator. */
export interface EngineResult extends EngineFinding {
  schemaVersion: typeof SCHEMA_VERSION;
  requestId: string;
  engineId: string;
  engineVersion: string;
}

export interface AnalysisRequest {
  requestId: string;
  userId: string;
  instrument: string;
  timeframes: Timeframe[];
  requestedAt: string;
  mode: AnalysisMode;
}
