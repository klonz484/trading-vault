import type { EngineContext, SpecialistEngine } from "./engine-interface";
import type { AnalysisRequest, EngineResult } from "./types";
import { SCHEMA_VERSION } from "./types";
import {
  formatViolations,
  validateAnalysisRequest,
  validateFinding,
  type Violation,
} from "./validate";

export type EngineRunStatus =
  | "completed"
  | "failed"
  | "timed_out"
  | "aborted"
  | "invalid_output"
  | "skipped";

export interface EngineRunRecord {
  engineId: string;
  engineVersion: string;
  status: EngineRunStatus;
  durationMs: number;
  detail?: string;
}

export interface OrchestrationOptions {
  /**
   * Wall-clock limit per engine. Deliberately required with no default: the
   * latency budget is still an open design item (see OPEN_DESIGN_ITEMS.md),
   * and a hung engine must never be able to block an analysis forever.
   */
  engineTimeoutMs: number;
  /** Cancels the whole analysis. */
  signal?: AbortSignal;
  /** Canonical instrument symbols; when given, the request is checked against them. */
  instruments?: readonly string[];
  /** Clock used for synthetic `unavailable` results. Injectable for tests. */
  now?: () => Date;
}

export interface OrchestrationResult {
  requestId: string;
  /** Registration order of engines, then the order each engine returned. Never completion order. */
  results: EngineResult[];
  warnings: string[];
  /** One record per engine: what happened and how long it took. */
  runs: EngineRunRecord[];
}

/** Thrown for programmer/configuration errors (bad request, bad engine graph, bad options). */
export class OrchestrationConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OrchestrationConfigError";
  }
}

/**
 * Orders engines into layers: every engine runs after everything it depends on
 * (hard or soft). Engines in the same layer run in parallel. Throws on
 * duplicate ids, unknown/self dependencies and cycles.
 */
export function planLayers(engines: readonly SpecialistEngine[]): SpecialistEngine[][] {
  const byId = new Map<string, SpecialistEngine>();
  for (const engine of engines) {
    if (typeof engine.id !== "string" || engine.id.length === 0) {
      throw new OrchestrationConfigError("Every engine needs a non-empty id");
    }
    if (byId.has(engine.id)) throw new OrchestrationConfigError(`Duplicate engine id "${engine.id}"`);
    byId.set(engine.id, engine);
  }

  const deps = new Map<string, string[]>();
  for (const engine of engines) {
    const all = [...(engine.dependsOn ?? []), ...(engine.softDependsOn ?? [])];
    for (const dep of all) {
      if (dep === engine.id) throw new OrchestrationConfigError(`Engine "${engine.id}" depends on itself`);
      if (!byId.has(dep)) throw new OrchestrationConfigError(`Engine "${engine.id}" depends on unknown engine "${dep}"`);
    }
    deps.set(engine.id, [...new Set(all)]);
  }

  const layers: SpecialistEngine[][] = [];
  const placed = new Set<string>();
  let remaining = engines.slice();
  while (remaining.length > 0) {
    const layer = remaining.filter((e) => (deps.get(e.id) ?? []).every((d) => placed.has(d)));
    if (layer.length === 0) {
      throw new OrchestrationConfigError(
        `Dependency cycle among engines: ${remaining.map((e) => e.id).join(", ")}`,
      );
    }
    layers.push(layer);
    for (const e of layer) placed.add(e.id);
    remaining = remaining.filter((e) => !placed.has(e.id));
  }
  return layers;
}

type Invocation =
  | { kind: "ok"; findings: unknown }
  | { kind: "error"; error: unknown }
  | { kind: "timeout" }
  | { kind: "aborted" };

async function invoke(
  engine: SpecialistEngine,
  request: AnalysisRequest,
  upstream: ReadonlyMap<string, readonly EngineResult[]>,
  timeoutMs: number,
  outer: AbortSignal | undefined,
): Promise<Invocation> {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let onOuterAbort: (() => void) | undefined;

  const stop = new Promise<Invocation>((resolve) => {
    timer = setTimeout(() => {
      controller.abort();
      resolve({ kind: "timeout" });
    }, timeoutMs);
    if (outer) {
      if (outer.aborted) {
        controller.abort();
        resolve({ kind: "aborted" });
      } else {
        onOuterAbort = () => {
          controller.abort();
          resolve({ kind: "aborted" });
        };
        outer.addEventListener("abort", onOuterAbort, { once: true });
      }
    }
  });

  const context: EngineContext = { signal: controller.signal, upstream };
  // `new Promise` captures a synchronous throw from analyze() as a rejection;
  // the attached handlers also guarantee a late rejection is never "unhandled".
  const work: Promise<Invocation> = new Promise<unknown>((resolve) =>
    resolve(engine.analyze(request, context)),
  ).then(
    (findings): Invocation => ({ kind: "ok", findings }),
    (error: unknown): Invocation => ({ kind: "error", error }),
  );

  try {
    return await Promise.race([work, stop]);
  } finally {
    clearTimeout(timer);
    if (outer && onOuterAbort) outer.removeEventListener("abort", onOuterAbort);
  }
}

function describeError(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

/**
 * Runs specialist engines in dependency order.
 *
 * Guarantees:
 * - an engine can fail, hang, throw synchronously or return garbage without
 *   affecting the others; the failure is reported as explicit `unavailable`
 *   results (never silence, never negative evidence);
 * - identity fields on every result (engine id/version, request id, schema
 *   version) are stamped here, not trusted from the engine;
 * - results from engines that answered a different instrument/timeframe, or
 *   that violate the result invariants, are rejected whole;
 * - output order is deterministic.
 *
 * Still open (see OPEN_DESIGN_ITEMS.md): retries, priority scheduling,
 * metrics/observability export, and the exact degraded-operation policy.
 */
export async function runSpecialists(
  request: AnalysisRequest,
  engines: readonly SpecialistEngine[],
  options: OrchestrationOptions,
): Promise<OrchestrationResult> {
  if (!(Number.isFinite(options.engineTimeoutMs) && options.engineTimeoutMs > 0)) {
    throw new OrchestrationConfigError("engineTimeoutMs must be a positive, finite number of milliseconds");
  }
  const requestViolations = validateAnalysisRequest(request, { instruments: options.instruments });
  if (requestViolations.length > 0) {
    throw new OrchestrationConfigError(`Invalid analysis request: ${formatViolations(requestViolations)}`);
  }
  const layers = planLayers(engines);
  const now = options.now ?? (() => new Date());

  const outcomes = new Map<string, { record: EngineRunRecord; results: EngineResult[] }>();
  const warnings: string[] = [];

  const unavailable = (engine: SpecialistEngine, reason: string): EngineResult[] =>
    request.timeframes.map((timeframe) => ({
      schemaVersion: SCHEMA_VERSION,
      requestId: request.requestId,
      engineId: engine.id,
      engineVersion: engine.version,
      instrument: request.instrument,
      timeframe,
      observedAt: now().toISOString(),
      state: "unavailable",
      direction: "unknown",
      confidence: null,
      candle: null,
      evidence: [],
      contraryEvidence: [],
      invalidation: null,
      sourceRefs: [],
      warnings: [reason],
    }));

  const fail = (
    engine: SpecialistEngine,
    status: Exclude<EngineRunStatus, "completed">,
    reason: string,
    durationMs: number,
  ): void => {
    warnings.push(`Engine ${engine.id} unavailable: ${reason}`);
    outcomes.set(engine.id, {
      record: { engineId: engine.id, engineVersion: engine.version, status, durationMs, detail: reason },
      results: unavailable(engine, reason),
    });
  };

  const usable = (id: string): boolean => {
    const outcome = outcomes.get(id);
    return !!outcome && outcome.record.status === "completed" && outcome.results.some((r) => r.state !== "unavailable");
  };

  const runOne = async (engine: SpecialistEngine): Promise<void> => {
    const started = performance.now();
    const elapsed = () => Math.round(performance.now() - started);

    const downHard = (engine.dependsOn ?? []).filter((id) => !usable(id));
    if (downHard.length > 0) {
      fail(engine, "skipped", `required engine(s) unavailable: ${downHard.join(", ")}`, 0);
      return;
    }

    const upstream = new Map<string, readonly EngineResult[]>();
    for (const id of new Set([...(engine.dependsOn ?? []), ...(engine.softDependsOn ?? [])])) {
      upstream.set(id, [...(outcomes.get(id)?.results ?? [])]);
    }

    const outcome = await invoke(engine, request, upstream, options.engineTimeoutMs, options.signal);

    if (outcome.kind === "timeout") return fail(engine, "timed_out", `timed out after ${options.engineTimeoutMs}ms`, elapsed());
    if (outcome.kind === "aborted") return fail(engine, "aborted", "analysis was cancelled", elapsed());
    if (outcome.kind === "error") return fail(engine, "failed", describeError(outcome.error), elapsed());

    const findings = outcome.findings;
    if (!Array.isArray(findings)) return fail(engine, "invalid_output", "engine must return an array of findings", elapsed());

    const violations: Violation[] = [];
    findings.forEach((finding: unknown, i: number) => {
      for (const v of validateFinding(finding)) violations.push({ path: `[${i}]${v.path.slice(1)}`, message: v.message });
      if (typeof finding === "object" && finding !== null) {
        const f = finding as { instrument?: unknown; timeframe?: unknown };
        if (f.instrument !== request.instrument) {
          violations.push({ path: `[${i}].instrument`, message: `must match the request (${request.instrument})` });
        }
        if (!(request.timeframes as readonly unknown[]).includes(f.timeframe)) {
          violations.push({ path: `[${i}].timeframe`, message: "must be one of the requested timeframes" });
        }
      }
    });
    if (violations.length > 0) {
      return fail(engine, "invalid_output", `result rejected: ${formatViolations(violations)}`, elapsed());
    }

    const results: EngineResult[] = (findings as Omit<EngineResult, "schemaVersion" | "requestId" | "engineId" | "engineVersion">[]).map((finding) => ({
      ...finding,
      schemaVersion: SCHEMA_VERSION,
      requestId: request.requestId,
      engineId: engine.id,
      engineVersion: engine.version,
    }));
    if (results.length === 0) warnings.push(`Engine ${engine.id} returned no results`);
    outcomes.set(engine.id, {
      record: { engineId: engine.id, engineVersion: engine.version, status: "completed", durationMs: elapsed() },
      results,
    });
  };

  for (const layer of layers) {
    await Promise.all(layer.map(runOne)); // runOne never rejects
  }

  const results: EngineResult[] = [];
  const runs: EngineRunRecord[] = [];
  for (const engine of engines) {
    const outcome = outcomes.get(engine.id);
    if (outcome) {
      results.push(...outcome.results);
      runs.push(outcome.record);
    }
  }
  return { requestId: request.requestId, results, warnings, runs };
}
