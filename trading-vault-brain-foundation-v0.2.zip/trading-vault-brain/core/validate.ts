import {
  ANALYSIS_MODES,
  DIRECTIONS,
  EVENT_STATES,
  SCHEMA_VERSION,
  TIMEFRAMES,
} from "./types";

export interface Violation {
  path: string;
  message: string;
}

const UTC_TIMESTAMP = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(\.\d+)?Z$/;

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * UTC ISO-8601 with a trailing `Z` that is also a real calendar instant.
 * `Date.parse` alone is not enough: it rolls "2026-02-31" over to March.
 */
export function isUtcTimestamp(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const m = UTC_TIMESTAMP.exec(value);
  if (!m) return false;
  const [year, month, day, hour, minute, second] = m.slice(1, 7).map(Number) as [number, number, number, number, number, number];
  if (month < 1 || month > 12 || hour > 23 || minute > 59 || second > 59) return false;
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return day >= 1 && day <= daysInMonth;
}

const FINDING_KEYS = [
  "instrument",
  "timeframe",
  "observedAt",
  "state",
  "direction",
  "confidence",
  "candle",
  "evidence",
  "contraryEvidence",
  "invalidation",
  "sourceRefs",
  "warnings",
] as const;

const STAMPED_KEYS = ["schemaVersion", "requestId", "engineId", "engineVersion"] as const;

const EVIDENCE_REQUIRED = ["id", "description", "observedAt", "timeframe", "source"] as const;
const EVIDENCE_OPTIONAL = ["weight", "metadata"] as const;

function checkKeys(
  rec: Record<string, unknown>,
  required: readonly string[],
  optional: readonly string[],
  path: string,
  out: Violation[],
): void {
  for (const key of required) {
    if (!(key in rec)) out.push({ path: `${path}.${key}`, message: "is required" });
  }
  const allowed = new Set<string>([...required, ...optional]);
  for (const key of Object.keys(rec)) {
    if (!allowed.has(key)) out.push({ path: `${path}.${key}`, message: "is not an allowed field" });
  }
}

function nonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.length > 0;
}

function checkStringArray(value: unknown, path: string, out: Violation[]): void {
  if (!Array.isArray(value)) {
    out.push({ path, message: "must be an array of strings" });
    return;
  }
  value.forEach((item, i) => {
    if (typeof item !== "string") out.push({ path: `${path}[${i}]`, message: "must be a string" });
  });
}

function checkEvidence(value: unknown, path: string, seenIds: Set<string>, out: Violation[]): void {
  if (!Array.isArray(value)) {
    out.push({ path, message: "must be an array of evidence items" });
    return;
  }
  value.forEach((item, i) => {
    const p = `${path}[${i}]`;
    if (!isRecord(item)) {
      out.push({ path: p, message: "must be an object" });
      return;
    }
    checkKeys(item, EVIDENCE_REQUIRED, EVIDENCE_OPTIONAL, p, out);
    if (!nonEmptyString(item.id)) {
      out.push({ path: `${p}.id`, message: "must be a non-empty string" });
    } else if (seenIds.has(item.id)) {
      out.push({ path: `${p}.id`, message: `duplicate evidence id "${item.id}"` });
    } else {
      seenIds.add(item.id);
    }
    if (!nonEmptyString(item.description)) out.push({ path: `${p}.description`, message: "must be a non-empty string" });
    if (!isUtcTimestamp(item.observedAt)) out.push({ path: `${p}.observedAt`, message: "must be a UTC timestamp ending in Z" });
    if (!(TIMEFRAMES as readonly unknown[]).includes(item.timeframe)) out.push({ path: `${p}.timeframe`, message: `must be one of ${TIMEFRAMES.join(", ")}` });
    if (!nonEmptyString(item.source)) out.push({ path: `${p}.source`, message: "must be a non-empty string (provenance)" });
    if ("weight" in item && !(typeof item.weight === "number" && Number.isFinite(item.weight))) out.push({ path: `${p}.weight`, message: "must be a finite number" });
    if ("metadata" in item && !isRecord(item.metadata)) out.push({ path: `${p}.metadata`, message: "must be an object" });
  });
}

/** Field-level and cross-field checks shared by findings and stamped results. */
function checkBody(rec: Record<string, unknown>, out: Violation[]): void {
  if (!nonEmptyString(rec.instrument)) out.push({ path: "$.instrument", message: "must be a non-empty string" });
  if (!(TIMEFRAMES as readonly unknown[]).includes(rec.timeframe)) out.push({ path: "$.timeframe", message: `must be one of ${TIMEFRAMES.join(", ")}` });
  if (!isUtcTimestamp(rec.observedAt)) out.push({ path: "$.observedAt", message: "must be a UTC timestamp ending in Z" });
  if (!(EVENT_STATES as readonly unknown[]).includes(rec.state)) out.push({ path: "$.state", message: `must be one of ${EVENT_STATES.join(", ")}` });
  if (!(DIRECTIONS as readonly unknown[]).includes(rec.direction)) out.push({ path: "$.direction", message: `must be one of ${DIRECTIONS.join(", ")}` });

  const c = rec.confidence;
  if (c !== null && !(typeof c === "number" && Number.isFinite(c) && c >= 0 && c <= 1)) {
    out.push({ path: "$.confidence", message: "must be null or a number from 0 to 1" });
  }

  const candle = rec.candle;
  let candleClosed: boolean | null = null; // null = no candle basis
  if (candle !== null) {
    if (!isRecord(candle)) {
      out.push({ path: "$.candle", message: "must be null or an object" });
    } else {
      checkKeys(candle, ["openTime", "closed"], [], "$.candle", out);
      if (!isUtcTimestamp(candle.openTime)) out.push({ path: "$.candle.openTime", message: "must be a UTC timestamp ending in Z" });
      if (typeof candle.closed !== "boolean") out.push({ path: "$.candle.closed", message: "must be a boolean" });
      else candleClosed = candle.closed;
    }
  }

  const seenIds = new Set<string>();
  checkEvidence(rec.evidence, "$.evidence", seenIds, out);
  checkEvidence(rec.contraryEvidence, "$.contraryEvidence", seenIds, out);

  if (rec.invalidation !== null && !isRecord(rec.invalidation)) out.push({ path: "$.invalidation", message: "must be null or an object" });
  checkStringArray(rec.sourceRefs, "$.sourceRefs", out);
  checkStringArray(rec.warnings, "$.warnings", out);

  // Invariants taken from the approved safety rules.
  if (rec.state === "unavailable") {
    // Missing data is not negative evidence: no directional claim, no confidence.
    if (rec.direction !== "unknown") out.push({ path: "$.direction", message: 'must be "unknown" when state is "unavailable"' });
    if (rec.confidence !== null) out.push({ path: "$.confidence", message: 'must be null when state is "unavailable"' });
  } else if (EVENT_STATES.includes(rec.state as never) && Array.isArray(rec.sourceRefs) && rec.sourceRefs.length === 0) {
    // Every available result carries provenance.
    out.push({ path: "$.sourceRefs", message: "must list at least one source for an available result" });
  }
  if (rec.state === "confirmed" && candleClosed === false) {
    // Forming-candle events stay provisional; confirmation needs a closed candle.
    out.push({ path: "$.candle.closed", message: 'must be true when state is "confirmed"' });
  }
}

/** Validates what an engine returns (no identity fields allowed). */
export function validateFinding(input: unknown): Violation[] {
  if (!isRecord(input)) return [{ path: "$", message: "must be an object" }];
  const out: Violation[] = [];
  checkKeys(input, FINDING_KEYS, [], "$", out);
  checkBody(input, out);
  return out;
}

/** Validates a stamped result (finding + identity fields). */
export function validateEngineResult(input: unknown): Violation[] {
  if (!isRecord(input)) return [{ path: "$", message: "must be an object" }];
  const out: Violation[] = [];
  checkKeys(input, [...STAMPED_KEYS, ...FINDING_KEYS], [], "$", out);
  if (input.schemaVersion !== SCHEMA_VERSION) out.push({ path: "$.schemaVersion", message: `must be "${SCHEMA_VERSION}"` });
  if (!nonEmptyString(input.requestId)) out.push({ path: "$.requestId", message: "must be a non-empty string" });
  if (!nonEmptyString(input.engineId)) out.push({ path: "$.engineId", message: "must be a non-empty string" });
  if (!nonEmptyString(input.engineVersion)) out.push({ path: "$.engineVersion", message: "must be a non-empty string" });
  checkBody(input, out);
  return out;
}

export interface RequestValidationOptions {
  /** Canonical instrument symbols (see configuration/instruments.json). */
  instruments?: readonly string[];
}

export function validateAnalysisRequest(
  input: unknown,
  options: RequestValidationOptions = {},
): Violation[] {
  if (!isRecord(input)) return [{ path: "$", message: "must be an object" }];
  const out: Violation[] = [];
  checkKeys(input, ["requestId", "userId", "instrument", "timeframes", "requestedAt", "mode"], [], "$", out);
  if (!nonEmptyString(input.requestId)) out.push({ path: "$.requestId", message: "must be a non-empty string" });
  if (!nonEmptyString(input.userId)) out.push({ path: "$.userId", message: "must be a non-empty string (tenant identity)" });
  if (!nonEmptyString(input.instrument)) {
    out.push({ path: "$.instrument", message: "must be a non-empty string" });
  } else if (options.instruments && !options.instruments.includes(input.instrument)) {
    out.push({ path: "$.instrument", message: `must be one of ${options.instruments.join(", ")}` });
  }
  if (!Array.isArray(input.timeframes) || input.timeframes.length === 0) {
    out.push({ path: "$.timeframes", message: "must be a non-empty array" });
  } else {
    const seen = new Set<unknown>();
    input.timeframes.forEach((tf: unknown, i: number) => {
      if (!(TIMEFRAMES as readonly unknown[]).includes(tf)) out.push({ path: `$.timeframes[${i}]`, message: `must be one of ${TIMEFRAMES.join(", ")}` });
      else if (seen.has(tf)) out.push({ path: `$.timeframes[${i}]`, message: "duplicate timeframe" });
      seen.add(tf);
    });
  }
  if (!isUtcTimestamp(input.requestedAt)) out.push({ path: "$.requestedAt", message: "must be a UTC timestamp ending in Z" });
  if (!(ANALYSIS_MODES as readonly unknown[]).includes(input.mode)) out.push({ path: "$.mode", message: `must be one of ${ANALYSIS_MODES.join(", ")}` });
  return out;
}

export function formatViolations(violations: readonly Violation[], max = 5): string {
  const shown = violations.slice(0, max).map((v) => `${v.path} ${v.message}`);
  const more = violations.length > max ? ` (+${violations.length - max} more)` : "";
  return shown.join("; ") + more;
}
