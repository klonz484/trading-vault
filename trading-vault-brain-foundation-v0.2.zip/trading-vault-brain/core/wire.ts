import type { EngineResult, EvidenceItem } from "./types";
import { isRecord, validateEngineResult, type Violation } from "./validate";

/**
 * In-code objects use camelCase; the JSON contracts use snake_case. These
 * explicit mappers are the only place the two meet, so a renamed field breaks a
 * test instead of silently producing messages that fail schema validation.
 * Free-form objects (`metadata`, `invalidation`) are passed through untouched.
 */

export interface WireEvidenceItem {
  id: string;
  description: string;
  observed_at: string;
  timeframe: string;
  source: string;
  weight?: number;
  metadata?: Record<string, unknown>;
}

export interface WireEngineResult {
  schema_version: string;
  request_id: string;
  engine_id: string;
  engine_version: string;
  instrument: string;
  timeframe: string;
  observed_at: string;
  state: string;
  direction: string;
  confidence: number | null;
  candle: { open_time: string; closed: boolean } | null;
  evidence: WireEvidenceItem[];
  contrary_evidence: WireEvidenceItem[];
  invalidation: Record<string, unknown> | null;
  source_refs: string[];
  warnings: string[];
}

function evidenceToWire(e: EvidenceItem): WireEvidenceItem {
  const out: WireEvidenceItem = {
    id: e.id,
    description: e.description,
    observed_at: e.observedAt,
    timeframe: e.timeframe,
    source: e.source,
  };
  if (e.weight !== undefined) out.weight = e.weight;
  if (e.metadata !== undefined) out.metadata = e.metadata;
  return out;
}

export function toWire(r: EngineResult): WireEngineResult {
  return {
    schema_version: r.schemaVersion,
    request_id: r.requestId,
    engine_id: r.engineId,
    engine_version: r.engineVersion,
    instrument: r.instrument,
    timeframe: r.timeframe,
    observed_at: r.observedAt,
    state: r.state,
    direction: r.direction,
    confidence: r.confidence,
    candle: r.candle ? { open_time: r.candle.openTime, closed: r.candle.closed } : null,
    evidence: r.evidence.map(evidenceToWire),
    contrary_evidence: r.contraryEvidence.map(evidenceToWire),
    invalidation: r.invalidation,
    source_refs: [...r.sourceRefs],
    warnings: [...r.warnings],
  };
}

const WIRE_KEYS = [
  "schema_version", "request_id", "engine_id", "engine_version", "instrument", "timeframe",
  "observed_at", "state", "direction", "confidence", "candle", "evidence", "contrary_evidence",
  "invalidation", "source_refs", "warnings",
] as const;

const WIRE_EVIDENCE_KEYS = ["id", "description", "observed_at", "timeframe", "source", "weight", "metadata"];

function evidenceFromWire(raw: unknown): unknown {
  if (!Array.isArray(raw)) return raw; // the validator reports the shape error
  return raw.map((item) => {
    if (!isRecord(item)) return item;
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(item)) {
      out[k === "observed_at" ? "observedAt" : k] = v;
    }
    return out;
  });
}

export type FromWireResult =
  | { ok: true; value: EngineResult }
  | { ok: false; violations: Violation[] };

/** Parses an untrusted snake_case message into a validated `EngineResult`. */
export function fromWire(input: unknown): FromWireResult {
  if (!isRecord(input)) return { ok: false, violations: [{ path: "$", message: "must be an object" }] };

  const violations: Violation[] = [];
  for (const key of Object.keys(input)) {
    if (!(WIRE_KEYS as readonly string[]).includes(key)) violations.push({ path: `$.${key}`, message: "is not an allowed field" });
  }
  for (const key of ["evidence", "contrary_evidence"] as const) {
    const items = input[key];
    if (Array.isArray(items)) {
      items.forEach((item, i) => {
        if (isRecord(item)) {
          for (const k of Object.keys(item)) {
            if (!WIRE_EVIDENCE_KEYS.includes(k)) violations.push({ path: `$.${key}[${i}].${k}`, message: "is not an allowed field" });
          }
        }
      });
    }
  }
  const candleRaw = input.candle;
  if (isRecord(candleRaw)) {
    for (const k of Object.keys(candleRaw)) {
      if (k !== "open_time" && k !== "closed") violations.push({ path: `$.candle.${k}`, message: "is not an allowed field" });
    }
  }

  const candle: unknown = isRecord(candleRaw)
    ? { openTime: candleRaw.open_time, closed: candleRaw.closed }
    : candleRaw;

  const camel = {
    schemaVersion: input.schema_version,
    requestId: input.request_id,
    engineId: input.engine_id,
    engineVersion: input.engine_version,
    instrument: input.instrument,
    timeframe: input.timeframe,
    observedAt: input.observed_at,
    state: input.state,
    direction: input.direction,
    confidence: input.confidence,
    candle,
    evidence: evidenceFromWire(input.evidence),
    contraryEvidence: evidenceFromWire(input.contrary_evidence),
    invalidation: input.invalidation,
    sourceRefs: input.source_refs,
    warnings: input.warnings,
  };

  // Missing wire fields become `undefined` here; report them by wire name.
  for (const key of WIRE_KEYS) {
    if (!(key in input)) violations.push({ path: `$.${key}`, message: "is required" });
  }
  if (violations.length > 0) return { ok: false, violations };

  const typeViolations = validateEngineResult(camel);
  if (typeViolations.length > 0) return { ok: false, violations: typeViolations };
  return { ok: true, value: camel as unknown as EngineResult };
}
