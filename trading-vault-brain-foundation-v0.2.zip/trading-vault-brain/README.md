# Trading Vault Brain — Foundation Package

**Status:** Foundation scaffold, version 0.2.0. Contracts, orchestration and tests are real; engines are still placeholders.  
**Execution mode:** Analysis and decision support only. Manual MT5 execution.  
**Initial market scope:** Forex majors + Gold (`forex_gold`).

This package is designed to be extracted into the existing Trading Vault repository as a separate Brain module. The Brain and Scanner remain independent systems and communicate only through versioned contracts.

## Important safety boundaries

- This package does not place, modify, or close trades.
- MT5 integration must remain read-only.
- No broker credentials, Supabase secrets, API keys, or service-role keys belong in this package.
- No strategy is considered profitable or validated merely because it is represented in code.
- Shared Core knowledge cannot be changed automatically by trader activity. Promotion requires controlled evaluation and owner approval.
- Private trader records must be isolated by authenticated user identity and database authorization.

## Package contents

- `core/`: shared types, result validator, wire-format mapper, engine interface and the orchestrator.
- `engines/`: specialist-engine interfaces and initial placeholders.
- `contracts/`: versioned Brain/Scanner and engine message contracts.
- `configuration/`: safe defaults and instrument coverage.
- `database/migrations/`: migration planning notes only; no schema is applied.
- `integrations/scanner/`: integration boundary.
- `knowledge/`: shared/private knowledge boundary.
- `experiments/`: controlled experiment record format.
- `tests/`: contract, validator, orchestrator and safety tests (plus the manual safety checklist).
- `documentation/`: architecture, decisions, open items and build sequence.

## Integration into Trading Vault

1. Extract this folder into the repository root.
2. Keep the existing Scanner code intact.
3. Review the proposed paths and resolve any naming collisions before merging.
4. The scaffold adds no dependencies to the repository. The tests run through `npx tsx`, which is fetched on demand and not saved to `package.json`.
5. Implement engines incrementally behind the contracts.
6. Add Supabase migrations only after the schema and RLS policies are reviewed.
7. Run the checks below and the repository build before opening a pull request.

See `documentation/EXTRACTION_GUIDE.md`.

## Checks

From inside the `trading-vault-brain/` folder:

```bash
npx tsc -p tsconfig.json
npx tsx --test tests/*.test.ts
```

The first is a strict typecheck of this package. The second runs the contract, validator, orchestrator and safety tests.

Note: once extracted into the repository, the Next.js typecheck also covers these `.ts` files, so keep imports inside `core/` and `engines/` extensionless (as they are now).

See `CHANGELOG.md` for what changed from the original foundation.

