# Scanner Integration Boundary

Scanner and Brain remain independent systems. This folder is the only intended
place for Scanner-specific adapters in this package.

Do not import Scanner internals into Brain specialist engines. Exchange
versioned messages using `contracts/scanner-brain-message.schema.json`.
Preserve the sender's original conclusion, provenance and uncertainty.
