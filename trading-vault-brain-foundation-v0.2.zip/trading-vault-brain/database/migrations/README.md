# Database Migration Gate

No Brain database migration is included yet. Before adding migrations:

1. Confirm the existing Trading Vault Supabase schema and naming conventions.
2. Design user-owned tables and storage ownership.
3. Write and test RLS policies for every private table and bucket.
4. Define Shared Core read/write permissions separately.
5. Add audit records for owner approvals and Core releases.
6. Test cross-user access denial using at least two test accounts.
7. Never put service-role keys in browser code or this package.

This deliberate gate prevents an unreviewed scaffold from weakening existing
authentication or tenant isolation.
