import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { fromWire, toWire } from "../core/wire";
import type { EngineResult } from "../core/types";
import { isUtcTimestamp, validateAnalysisRequest, validateEngineResult, validateFinding } from "../core/validate";
import { evidence, finding, request, T0 } from "./fixtures";

const paths = (v: { path: string }[]) => v.map((x) => x.path);

function stamped(overrides: Partial<EngineResult> = {}): EngineResult {
  return { ...finding(), schemaVersion: "1.0.0", requestId: "req-1", engineId: "e", engineVersion: "0.0.1", ...overrides };
}

describe("isUtcTimestamp", () => {
  it("accepts Z timestamps and rejects offsets, local times and impossible dates", () => {
    assert.ok(isUtcTimestamp("2026-11-05T10:00:00Z"));
    assert.ok(isUtcTimestamp("2026-11-05T10:00:00.123Z"));
    assert.ok(!isUtcTimestamp("2026-11-05T10:00:00+02:00"));
    assert.ok(!isUtcTimestamp("2026-11-05T10:00:00"));
    assert.ok(!isUtcTimestamp("2026-02-31T10:00:00Z"));
    assert.ok(!isUtcTimestamp("2026-13-01T10:00:00Z"));
    assert.ok(!isUtcTimestamp("2026-11-05T24:00:00Z"));
    assert.ok(isUtcTimestamp("2028-02-29T23:59:59Z"), "leap day");
    assert.ok(!isUtcTimestamp("2026-02-29T00:00:00Z"), "not a leap year");
    assert.ok(!isUtcTimestamp(1730800000000));
  });
});

describe("validateFinding", () => {
  it("accepts a well-formed finding", () => {
    assert.deepEqual(validateFinding(finding()), []);
  });

  it("rejects out-of-range or non-finite confidence", () => {
    assert.deepEqual(paths(validateFinding(finding({ confidence: 1.2 }))), ["$.confidence"]);
    assert.deepEqual(paths(validateFinding(finding({ confidence: Number.NaN }))), ["$.confidence"]);
    assert.deepEqual(validateFinding(finding({ confidence: null })), []);
  });

  it("rejects identity fields: engines cannot stamp their own identity", () => {
    const forged = { ...finding(), engineId: "someone-else" };
    assert.deepEqual(paths(validateFinding(forged)), ["$.engineId"]);
  });

  it("rejects unknown timeframes and non-UTC timestamps", () => {
    assert.ok(paths(validateFinding({ ...finding(), timeframe: "H2" })).includes("$.timeframe"));
    assert.ok(paths(validateFinding(finding({ observedAt: "2026-11-05T10:00:00+01:00" }))).includes("$.observedAt"));
  });

  it("unavailable results must make no directional claim and carry no confidence", () => {
    const bad = finding({ state: "unavailable", direction: "bullish", confidence: 0.7, sourceRefs: [] });
    assert.deepEqual(paths(validateFinding(bad)).sort(), ["$.confidence", "$.direction"]);
    const good = finding({ state: "unavailable", direction: "unknown", confidence: null, sourceRefs: [] });
    assert.deepEqual(validateFinding(good), []);
  });

  it("available results must carry provenance", () => {
    assert.deepEqual(paths(validateFinding(finding({ sourceRefs: [] }))), ["$.sourceRefs"]);
  });

  it("a confirmed result cannot rest on a forming candle", () => {
    const bad = finding({ state: "confirmed", candle: { openTime: T0, closed: false } });
    assert.deepEqual(paths(validateFinding(bad)), ["$.candle.closed"]);
    assert.deepEqual(validateFinding(finding({ state: "confirmed", candle: { openTime: T0, closed: true } })), []);
    assert.deepEqual(validateFinding(finding({ state: "confirmed", candle: null })), []);
  });

  it("evidence needs provenance and unique ids across evidence and contrary evidence", () => {
    const noSource = finding({ evidence: [evidence("e1", { source: "" })] });
    assert.deepEqual(paths(validateFinding(noSource)), ["$.evidence[0].source"]);
    const dup = finding({ evidence: [evidence("x")], contraryEvidence: [evidence("x")] });
    assert.deepEqual(paths(validateFinding(dup)), ["$.contraryEvidence[0].id"]);
  });
});

describe("validateAnalysisRequest", () => {
  it("accepts a good request and enforces the instrument list when given", () => {
    assert.deepEqual(validateAnalysisRequest(request()), []);
    assert.deepEqual(validateAnalysisRequest(request(), { instruments: ["EURUSD"] }), []);
    assert.deepEqual(paths(validateAnalysisRequest(request({ instrument: "BTCUSD" }), { instruments: ["EURUSD"] })), ["$.instrument"]);
  });

  it("requires tenant identity, timeframes without duplicates, and a UTC time", () => {
    assert.deepEqual(paths(validateAnalysisRequest(request({ userId: "" }))), ["$.userId"]);
    assert.deepEqual(paths(validateAnalysisRequest(request({ timeframes: [] }))), ["$.timeframes"]);
    assert.deepEqual(paths(validateAnalysisRequest(request({ timeframes: ["H1", "H1"] }))), ["$.timeframes[1]"]);
    assert.deepEqual(paths(validateAnalysisRequest(request({ requestedAt: "2026-11-05" }))), ["$.requestedAt"]);
  });
});

describe("wire mapping", () => {
  it("round-trips a result through the snake_case wire format", () => {
    const original = stamped({ evidence: [evidence("e1", { weight: 2, metadata: { camelCaseKey: 1 } })] });
    const parsed = fromWire(JSON.parse(JSON.stringify(toWire(original))));
    assert.ok(parsed.ok);
    assert.deepEqual(parsed.value, original);
  });

  it("does not rewrite keys inside free-form metadata or invalidation", () => {
    const original = stamped({ invalidation: { priceLevel: 1.1 }, evidence: [evidence("e1", { metadata: { someKey: true } })] });
    const wire = toWire(original);
    assert.deepEqual(wire.invalidation, { priceLevel: 1.1 });
    assert.deepEqual(wire.evidence[0]?.metadata, { someKey: true });
  });

  it("rejects camelCase input, unknown fields and missing fields with wire names", () => {
    const camel = fromWire(stamped());
    assert.ok(!camel.ok);
    const wire = toWire(stamped());
    const extra = fromWire({ ...wire, surprise: 1 });
    assert.ok(!extra.ok && extra.violations.some((v) => v.path === "$.surprise"));
    const { engine_id: _omit, ...missing } = wire;
    const gone = fromWire(missing);
    assert.ok(!gone.ok && gone.violations.some((v) => v.path === "$.engine_id"));
  });

  it("applies the result invariants to wire input", () => {
    const wire = toWire(stamped({ state: "confirmed", candle: { openTime: T0, closed: false } }));
    const parsed = fromWire(wire);
    assert.ok(!parsed.ok);
  });
});

describe("validateEngineResult", () => {
  it("requires stamped identity fields", () => {
    assert.deepEqual(validateEngineResult(stamped()), []);
    assert.ok(paths(validateEngineResult(finding())).includes("$.engineId"));
    assert.ok(paths(validateEngineResult(stamped({ engineVersion: "" }))).includes("$.engineVersion"));
  });
});
