/**
 * Tiny JSON Schema checker covering exactly the keywords used by the files in
 * contracts/. It exists so the contract tests can exercise the real schema
 * files without adding a dependency. If a contract starts using a keyword
 * that is not handled here, the checker throws instead of silently passing.
 */
export interface Schema {
  $schema?: string;
  $id?: string;
  title?: string;
  description?: string;
  $ref?: string;
  $defs?: Record<string, Schema>;
  type?: string | string[];
  enum?: unknown[];
  const?: unknown;
  required?: string[];
  properties?: Record<string, Schema>;
  additionalProperties?: boolean | Schema;
  items?: Schema;
  minItems?: number;
  minimum?: number;
  maximum?: number;
  minLength?: number;
  pattern?: string;
  allOf?: Schema[];
  if?: Schema;
  then?: Schema;
}

const HANDLED = new Set([
  "$schema", "$id", "title", "description", "$ref", "$defs", "type", "enum", "const",
  "required", "properties", "additionalProperties", "items", "minItems", "minimum",
  "maximum", "minLength", "pattern", "allOf", "if", "then",
]);

function typeOf(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}

function resolve(ref: string, root: Schema): Schema {
  if (!ref.startsWith("#/$defs/")) throw new Error(`Unsupported $ref ${ref}`);
  const target = root.$defs?.[ref.slice("#/$defs/".length)];
  if (!target) throw new Error(`Unresolved $ref ${ref}`);
  return target;
}

export function check(schema: Schema, data: unknown, root: Schema = schema, path = "$"): string[] {
  for (const key of Object.keys(schema)) {
    if (!HANDLED.has(key)) throw new Error(`mini-schema does not support keyword "${key}"`);
  }
  if (schema.$ref) return check(resolve(schema.$ref, root), data, root, path);

  const errors: string[] = [];
  const t = typeOf(data);

  if (schema.type !== undefined) {
    const allowed = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!allowed.includes(t)) errors.push(`${path}: expected ${allowed.join("|")}, got ${t}`);
  }
  if (schema.enum && !schema.enum.some((v) => v === data)) errors.push(`${path}: not in enum`);
  if ("const" in schema && schema.const !== data) errors.push(`${path}: must equal ${JSON.stringify(schema.const)}`);

  if (typeof data === "string") {
    if (schema.minLength !== undefined && data.length < schema.minLength) errors.push(`${path}: too short`);
    if (schema.pattern && !new RegExp(schema.pattern).test(data)) errors.push(`${path}: pattern mismatch`);
  }
  if (typeof data === "number") {
    if (schema.minimum !== undefined && data < schema.minimum) errors.push(`${path}: below minimum`);
    if (schema.maximum !== undefined && data > schema.maximum) errors.push(`${path}: above maximum`);
  }
  if (Array.isArray(data)) {
    if (schema.minItems !== undefined && data.length < schema.minItems) errors.push(`${path}: too few items`);
    if (schema.items) data.forEach((item, i) => errors.push(...check(schema.items as Schema, item, root, `${path}[${i}]`)));
  }
  if (t === "object") {
    const obj = data as Record<string, unknown>;
    for (const key of schema.required ?? []) {
      if (!(key in obj)) errors.push(`${path}.${key}: required`);
    }
    for (const [key, sub] of Object.entries(schema.properties ?? {})) {
      if (key in obj) errors.push(...check(sub, obj[key], root, `${path}.${key}`));
    }
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(obj)) {
        if (!(key in (schema.properties ?? {}))) errors.push(`${path}.${key}: additional property`);
      }
    }
  }
  for (const sub of schema.allOf ?? []) errors.push(...check(sub, data, root, path));
  if (schema.if && check(schema.if, data, root, path).length === 0 && schema.then) {
    errors.push(...check(schema.then, data, root, path));
  }
  return errors;
}
