import assert from "node:assert/strict";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { describe, it } from "node:test";
import { dirname, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const SKIP_DIRS = new Set(["node_modules", "dist", "coverage", ".git", "tests"]);

function walk(dir: string, exts: string[]): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    if (SKIP_DIRS.has(name)) continue;
    const full = join(dir, name);
    if (statSync(full).isDirectory()) out.push(...walk(full, exts));
    else if (exts.some((e) => name.endsWith(e))) out.push(full);
  }
  return out;
}

const sources = walk(ROOT, [".ts", ".json"]);
const read = (p: string) => readFileSync(p, "utf8");
const json = <T>(rel: string) => JSON.parse(read(join(ROOT, rel))) as T;

describe("execution safety: analysis and decision support only", () => {
  it("configuration forbids order execution and keeps MT5 read-only", () => {
    const cfg = json<{ execution: { mode: string; allow_order_execution: boolean }; market_data: { mt5_access: string } }>("configuration/instruments.json");
    assert.equal(cfg.execution.allow_order_execution, false);
    assert.equal(cfg.execution.mode, "manual_mt5");
    assert.equal(cfg.market_data.mt5_access, "read_only");
  });

  it("no source or config file contains order-placement capability", () => {
    const forbidden = /\b(order_send|OrderSend|order_check|placeOrder|place_order|submitOrder|submit_order|modifyOrder|modify_order|closePosition|close_position|cancelOrder|cancel_order|createOrder|create_order|TRADE_ACTION_DEAL|TRADE_ACTION_PENDING|TRADE_ACTION_SLTP)\b/;
    const hits = sources.filter((f) => forbidden.test(read(f))).map((f) => relative(ROOT, f));
    assert.deepEqual(hits, []);
  });
});

describe("secrets", () => {
  it("no keys, tokens or service-role references in source or config", () => {
    const patterns = [/service_role/i, /SUPABASE_SERVICE/i, /\bsk-[A-Za-z0-9]{20,}/, /eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/, /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /api[_-]?key\s*["']?\s*[:=]\s*["'][^"']{8,}/i];
    const hits = sources.filter((f) => patterns.some((p) => p.test(read(f)))).map((f) => relative(ROOT, f));
    assert.deepEqual(hits, []);
  });

  it(".gitignore keeps env files out but allows .env.example", () => {
    const lines = read(join(ROOT, ".gitignore")).split(/\r?\n/);
    assert.ok(lines.includes(".env"));
    assert.ok(lines.includes(".env.*"));
    assert.ok(lines.includes("!.env.example"));
  });
});

describe("governance", () => {
  it("Shared Core cannot be auto-promoted and needs owner approval", () => {
    const d = json<{ governance: { shared_core_auto_promotion: boolean; shared_core_requires_owner_approval: boolean } }>("configuration/brain.defaults.json");
    assert.equal(d.governance.shared_core_auto_promotion, false);
    assert.equal(d.governance.shared_core_requires_owner_approval, true);
  });

  it("the experiment template cannot promote without owner approval", () => {
    const t = json<{ shared_core_promotion: string; status: string }>("experiments/experiment-record.template.json");
    assert.equal(t.shared_core_promotion, "not_allowed_without_owner_approval");
    assert.equal(t.status, "draft");
  });
});

describe("independence: engines and core stay self-contained", () => {
  const importSpecifier = /(?:from\s+|import\s*\(\s*|require\s*\(\s*)["']([^"']+)["']/g;
  const guarded = walk(join(ROOT, "core"), [".ts"]).concat(walk(join(ROOT, "engines"), [".ts"]));

  it("core/ and engines/ import only from the Brain package (no host-app or Scanner code)", () => {
    const violations: string[] = [];
    for (const file of guarded) {
      for (const m of read(file).matchAll(importSpecifier)) {
        const spec = m[1] as string;
        if (spec.startsWith("node:")) continue;
        if (!spec.startsWith(".")) {
          violations.push(`${relative(ROOT, file)} imports package/alias "${spec}"`);
          continue;
        }
        const target = resolve(dirname(file), spec);
        const rel = relative(ROOT, target);
        const top = rel.split(sep)[0];
        if (rel.startsWith("..") || top === "integrations") {
          violations.push(`${relative(ROOT, file)} imports "${spec}" outside core/engines`);
        }
      }
    }
    assert.deepEqual(violations, []);
  });
});
