import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { OrchestrationConfigError, planLayers, runSpecialists } from "../core/orchestrator";
import { validateEngineResult } from "../core/validate";
import { engine, finding, request } from "./fixtures";

const OPTS = { engineTimeoutMs: 200 };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const never = () => new Promise<never>(() => {});

describe("runSpecialists: happy path", () => {
  it("stamps identity fields and returns validated, schema-conformant results", async () => {
    const out = await runSpecialists(request(), [engine("a"), engine("b")], OPTS);
    assert.equal(out.results.length, 2);
    for (const r of out.results) assert.deepEqual(validateEngineResult(r), []);
    assert.deepEqual(out.results.map((r) => [r.engineId, r.requestId, r.engineVersion]), [
      ["a", "req-1", "0.0.1"],
      ["b", "req-1", "0.0.1"],
    ]);
    assert.deepEqual(out.runs.map((r) => r.status), ["completed", "completed"]);
    assert.deepEqual(out.warnings, []);
  });

  it("returns results in registration order, not completion order", async () => {
    const slow = engine("slow", async () => (await sleep(40), [finding()]));
    const fast = engine("fast");
    const out = await runSpecialists(request(), [slow, fast], OPTS);
    assert.deepEqual(out.results.map((r) => r.engineId), ["slow", "fast"]);
  });

  it("runs independent engines in parallel", async () => {
    const started: string[] = [];
    const mk = (id: string) => engine(id, async () => (started.push(id), await sleep(30), [finding()]));
    const t0 = Date.now();
    await runSpecialists(request(), [mk("a"), mk("b"), mk("c")], OPTS);
    assert.ok(Date.now() - t0 < 85, "three 30ms engines should overlap");
    assert.equal(started.length, 3);
  });
});

describe("runSpecialists: failure isolation (fail closed, never silent)", () => {
  it("an engine that throws becomes an explicit unavailable result for each requested timeframe", async () => {
    const bad = engine("bad", async () => {
      throw new Error("boom");
    });
    const out = await runSpecialists(request({ timeframes: ["M15", "H1"] }), [bad, engine("ok")], OPTS);
    const unavailable = out.results.filter((r) => r.engineId === "bad");
    assert.deepEqual(unavailable.map((r) => [r.timeframe, r.state, r.direction, r.confidence]), [
      ["M15", "unavailable", "unknown", null],
      ["H1", "unavailable", "unknown", null],
    ]);
    for (const r of out.results) assert.deepEqual(validateEngineResult(r), []);
    assert.match(out.warnings[0] ?? "", /bad unavailable: boom/);
    assert.equal(out.runs[0]?.status, "failed");
    assert.equal(out.results.filter((r) => r.engineId === "ok").length, 1, "other engines are unaffected");
  });

  it("a synchronous throw inside analyze() is contained", async () => {
    const sync: ReturnType<typeof engine> = { id: "sync", version: "1", analyze: () => { throw new Error("sync boom"); } };
    const out = await runSpecialists(request(), [sync], OPTS);
    assert.equal(out.runs[0]?.status, "failed");
  });

  it("a hung engine times out, is aborted, and does not block the others", async () => {
    let aborted = false;
    const hung = engine("hung", (_req, ctx) => {
      ctx.signal.addEventListener("abort", () => { aborted = true; });
      return never();
    });
    const t0 = Date.now();
    const out = await runSpecialists(request(), [hung, engine("ok")], { engineTimeoutMs: 40 });
    assert.ok(Date.now() - t0 < 150);
    assert.equal(out.runs[0]?.status, "timed_out");
    assert.equal(out.results.find((r) => r.engineId === "hung")?.state, "unavailable");
    assert.ok(aborted, "engine receives the abort signal");
  });

  it("cancelling the analysis marks running engines aborted", async () => {
    const ctrl = new AbortController();
    setTimeout(() => ctrl.abort(), 20);
    const out = await runSpecialists(request(), [engine("slow", never)], { engineTimeoutMs: 1000, signal: ctrl.signal });
    assert.equal(out.runs[0]?.status, "aborted");
  });

  it("an already-aborted signal short-circuits", async () => {
    const ctrl = new AbortController();
    ctrl.abort();
    const out = await runSpecialists(request(), [engine("a")], { engineTimeoutMs: 1000, signal: ctrl.signal });
    assert.equal(out.runs[0]?.status, "aborted");
  });

  it("garbage output is rejected whole: invariants, wrong instrument, wrong timeframe, forged identity", async () => {
    const cases: [string, unknown][] = [
      ["not an array", { nope: true }],
      ["confirmed on a forming candle", [finding({ state: "confirmed", candle: { openTime: "2026-11-05T10:00:00Z", closed: false } })]],
      ["wrong instrument", [finding({ instrument: "GBPUSD" })]],
      ["unrequested timeframe", [finding({ timeframe: "D1" })]],
      ["forged identity", [{ ...finding(), engineId: "someone-else" }]],
      ["one good, one bad", [finding(), finding({ confidence: 5 })]],
    ];
    for (const [label, output] of cases) {
      const out = await runSpecialists(request(), [engine("x", async () => output as never)], OPTS);
      assert.equal(out.runs[0]?.status, "invalid_output", label);
      assert.ok(out.results.every((r) => r.state === "unavailable"), label);
    }
  });
});

describe("runSpecialists: dependencies", () => {
  it("runs dependents after their dependencies and exposes only declared upstream results", async () => {
    const seen: Record<string, string[]> = {};
    const a = engine("a");
    const b = engine("b");
    const c = engine("c", async (_r, ctx) => (seen.c = [...ctx.upstream.keys()], [finding()]), { dependsOn: ["a"] });
    await runSpecialists(request(), [c, a, b], OPTS);
    assert.deepEqual(seen.c, ["a"], "c sees a but not b");
  });

  it("upstream results carry the stamped, validated data", async () => {
    let upstreamEngine = "";
    const a = engine("a");
    const b = engine("b", async (_r, ctx) => (upstreamEngine = ctx.upstream.get("a")?.[0]?.engineId ?? "", [finding()]), { dependsOn: ["a"] });
    await runSpecialists(request(), [a, b], OPTS);
    assert.equal(upstreamEngine, "a");
  });

  it("skips an engine whose hard dependency failed, and cascades", async () => {
    const a = engine("a", async () => { throw new Error("down"); });
    let bRan = false;
    const b = engine("b", async () => (bRan = true, [finding()]), { dependsOn: ["a"] });
    const c = engine("c", async () => [finding()], { dependsOn: ["b"] });
    const out = await runSpecialists(request(), [a, b, c], OPTS);
    assert.equal(bRan, false);
    assert.deepEqual(out.runs.map((r) => r.status), ["failed", "skipped", "skipped"]);
    assert.ok(out.results.every((r) => r.state === "unavailable"));
  });

  it("treats a dependency that only reported unavailable as unusable", async () => {
    const a = engine("a", async () => [finding({ state: "unavailable", direction: "unknown", confidence: null, sourceRefs: [], candle: null, warnings: ["data gap"] })]);
    const b = engine("b", async () => [finding()], { dependsOn: ["a"] });
    const out = await runSpecialists(request(), [a, b], OPTS);
    assert.deepEqual(out.runs.map((r) => r.status), ["completed", "skipped"]);
  });

  it("still runs an engine whose soft dependency is unavailable (degraded operation)", async () => {
    const a = engine("a", async () => { throw new Error("down"); });
    let sawUnavailable = false;
    const b = engine("b", async (_r, ctx) => (sawUnavailable = ctx.upstream.get("a")?.[0]?.state === "unavailable", [finding()]), { softDependsOn: ["a"] });
    const out = await runSpecialists(request(), [a, b], OPTS);
    assert.equal(out.runs[1]?.status, "completed");
    assert.ok(sawUnavailable, "the engine is told its input is unavailable");
  });
});

describe("planLayers and configuration errors", () => {
  it("layers by dependency, preserving registration order inside a layer", () => {
    const layers = planLayers([
      engine("c", undefined, { dependsOn: ["a", "b"] }),
      engine("a"),
      engine("b"),
      engine("d", undefined, { softDependsOn: ["c"] }),
    ]);
    assert.deepEqual(layers.map((l) => l.map((e) => e.id)), [["a", "b"], ["c"], ["d"]]);
  });

  it("rejects duplicates, unknown and self dependencies, and cycles", () => {
    assert.throws(() => planLayers([engine("a"), engine("a")]), OrchestrationConfigError);
    assert.throws(() => planLayers([engine("a", undefined, { dependsOn: ["ghost"] })]), /unknown engine "ghost"/);
    assert.throws(() => planLayers([engine("a", undefined, { dependsOn: ["a"] })]), /itself/);
    assert.throws(() => planLayers([engine("a", undefined, { dependsOn: ["b"] }), engine("b", undefined, { softDependsOn: ["a"] })]), /cycle/);
  });

  it("refuses to run without a usable timeout or with an invalid request", async () => {
    await assert.rejects(runSpecialists(request(), [engine("a")], { engineTimeoutMs: 0 }), OrchestrationConfigError);
    await assert.rejects(runSpecialists(request(), [engine("a")], { engineTimeoutMs: Number.NaN }), OrchestrationConfigError);
    await assert.rejects(runSpecialists(request({ userId: "" }), [engine("a")], OPTS), /Invalid analysis request/);
    await assert.rejects(runSpecialists(request({ instrument: "BTCUSD" }), [engine("a")], { ...OPTS, instruments: ["EURUSD"] }), /instrument/);
  });
});
