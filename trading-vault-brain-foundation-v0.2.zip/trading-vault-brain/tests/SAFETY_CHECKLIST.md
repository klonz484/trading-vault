# Safety / Acceptance Checklist

"Automated" items are enforced by the tests in this folder. "Manual" items need a human check or a test that cannot exist until the relevant part is built.

| Check | Verification |
|---|---|
| No order execution capability exists | Automated: `safety.test.ts` scans source/config for order-placement identifiers and checks `allow_order_execution: false` |
| MT5 connection is read-only | Automated for configuration; Manual review once the MT5 adapter exists |
| Forming-candle events remain provisional | Automated: `validate.test.ts`, `contracts.test.ts` (confirmed requires a closed candle) |
| Confirmed structure requires closed-candle rules | Automated at the contract level; engine-level tests required when Market Structure is built |
| Every result includes instrument, timeframe, UTC timestamp and provenance | Automated: validator + JSON schema |
| Conflicts and contrary evidence are preserved | Partly automated (separate required field); Manual until Confluence exists |
| Missing data is not treated as negative evidence | Automated: `unavailable` invariant; failures and skips become `unavailable` (`orchestrator.test.ts`) |
| Shared Core cannot be auto-promoted by private user activity | Automated for configuration and experiment template; Manual once promotion code exists |
| Private trader data is tenant-isolated | Manual: needs RLS policies and a two-account denial test (see `database/migrations/README.md`) |
| Scanner and Brain retain independent conclusions | Automated: `core/` and `engines/` may not import Scanner, host-app or `integrations/` code; messages must be `evidence` and carry provenance |
| Strategy claims are validated with reproducible replay/out-of-sample tests | Manual: depends on the Learning and Validation engines |
| Provider/API secrets are not committed | Automated: secret-pattern scan and `.gitignore` check |

Run: `npx tsx --test tests/*.test.ts` from the `trading-vault-brain/` folder.
