import type { SpecialistEngine } from "../core/engine-interface";
import type { AnalysisRequest, EngineFinding, EvidenceItem } from "../core/types";

export const T0 = "2026-11-05T10:00:00.000Z";

export function evidence(id: string, overrides: Partial<EvidenceItem> = {}): EvidenceItem {
  return {
    id,
    description: `evidence ${id}`,
    observedAt: T0,
    timeframe: "H1",
    source: "fixture:candles",
    ...overrides,
  };
}

export function finding(overrides: Partial<EngineFinding> = {}): EngineFinding {
  return {
    instrument: "EURUSD",
    timeframe: "H1",
    observedAt: T0,
    state: "provisional",
    direction: "bullish",
    confidence: 0.6,
    candle: { openTime: T0, closed: false },
    evidence: [evidence("e1")],
    contraryEvidence: [],
    invalidation: { note: "fixture" },
    sourceRefs: ["fixture:EURUSD:H1"],
    warnings: [],
    ...overrides,
  };
}

export function request(overrides: Partial<AnalysisRequest> = {}): AnalysisRequest {
  return {
    requestId: "req-1",
    userId: "user-1",
    instrument: "EURUSD",
    timeframes: ["H1"],
    requestedAt: T0,
    mode: "user_triggered",
    ...overrides,
  };
}

export function engine(
  id: string,
  analyze: SpecialistEngine["analyze"] = async () => [finding()],
  extra: Partial<Pick<SpecialistEngine, "dependsOn" | "softDependsOn" | "version">> = {},
): SpecialistEngine {
  return { id, version: "0.0.1", analyze, ...extra };
}
