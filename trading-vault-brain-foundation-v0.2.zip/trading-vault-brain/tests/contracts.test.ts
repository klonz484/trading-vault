import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { describe, it } from "node:test";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { toWire } from "../core/wire";
import { ANALYSIS_MODES, DIRECTIONS, EVENT_STATES, SCHEMA_VERSION, TIMEFRAMES } from "../core/types";
import type { EngineResult } from "../core/types";
import { check, type Schema } from "./helpers/mini-schema";
import { evidence, finding, T0 } from "./fixtures";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const load = <T>(rel: string): T => JSON.parse(readFileSync(join(ROOT, rel), "utf8")) as T;

const resultSchema = load<Schema>("contracts/engine-result.schema.json");
const messageSchema = load<Schema>("contracts/scanner-brain-message.schema.json");
const instruments = load<{ timeframes: string[]; instruments: string[] }>("configuration/instruments.json");

function stamped(overrides: Partial<EngineResult> = {}): EngineResult {
  return { ...finding(), schemaVersion: SCHEMA_VERSION, requestId: "req-1", engineId: "e", engineVersion: "0.0.1", ...overrides };
}
const wireErrors = (r: EngineResult) => check(resultSchema, JSON.parse(JSON.stringify(toWire(r))));

describe("engine-result schema accepts what the code produces", () => {
  it("provisional, confirmed (closed candle), invalidated and unavailable results", () => {
    assert.deepEqual(wireErrors(stamped()), []);
    assert.deepEqual(wireErrors(stamped({ state: "confirmed", candle: { openTime: T0, closed: true } })), []);
    assert.deepEqual(wireErrors(stamped({ state: "invalidated", direction: "neutral" })), []);
    assert.deepEqual(
      wireErrors(stamped({ state: "unavailable", direction: "unknown", confidence: null, sourceRefs: [], candle: null, warnings: ["no data"] })),
      [],
    );
  });

  it("evidence with optional weight and metadata, and contrary evidence", () => {
    const r = stamped({ evidence: [evidence("a", { weight: 1.5, metadata: { k: 1 } })], contraryEvidence: [evidence("b")] });
    assert.deepEqual(wireErrors(r), []);
  });
});

describe("engine-result schema rejects what it must", () => {
  const base = () => JSON.parse(JSON.stringify(toWire(stamped()))) as Record<string, unknown>;
  const reject = (mutate: (w: Record<string, unknown>) => void) => {
    const w = base();
    mutate(w);
    assert.notDeepEqual(check(resultSchema, w), [], "schema should reject this");
  };

  it("missing required fields, unknown fields, camelCase", () => {
    reject((w) => delete w.request_id);
    reject((w) => delete w.contrary_evidence);
    reject((w) => delete w.source_refs);
    reject((w) => (w.surprise = true));
    reject((w) => {
      w.engineId = "x";
      delete w.engine_id;
    });
  });

  it("bad enums, confidence, non-UTC timestamps", () => {
    reject((w) => (w.state = "maybe"));
    reject((w) => (w.timeframe = "H2"));
    reject((w) => (w.confidence = 1.01));
    reject((w) => (w.observed_at = "2026-11-05T10:00:00+02:00"));
  });

  it("an unavailable result that claims a direction or confidence", () => {
    reject((w) => {
      w.state = "unavailable";
      w.direction = "bullish";
    });
    reject((w) => {
      w.state = "unavailable";
      w.direction = "unknown";
      w.confidence = 0.5;
    });
  });

  it("an available result with no provenance", () => {
    reject((w) => (w.source_refs = []));
  });

  it("a confirmed result resting on a forming candle", () => {
    reject((w) => {
      w.state = "confirmed";
      w.candle = { open_time: T0, closed: false };
    });
  });

  it("evidence items with missing provenance or unknown fields", () => {
    reject((w) => ((w.evidence as Record<string, unknown>[])[0]!.source = ""));
    reject((w) => ((w.evidence as Record<string, unknown>[])[0]!.extra = 1));
  });
});

describe("scanner-brain message schema", () => {
  const good = () => ({
    schema_version: "1.0.0",
    message_id: "m1",
    message_kind: "evidence",
    sender: "scanner",
    sent_at: T0,
    instrument: "EURUSD",
    timeframes: ["H1"],
    payload: { conclusion: "example" },
    provenance: { source: "scanner" },
    correlation_id: null,
  });

  it("accepts evidence messages that carry provenance", () => {
    assert.deepEqual(check(messageSchema, good()), []);
  });

  it("rejects commands, missing provenance and bad timeframes", () => {
    assert.notDeepEqual(check(messageSchema, { ...good(), message_kind: "command" }), []);
    const { provenance: _p, ...noProvenance } = good();
    assert.notDeepEqual(check(messageSchema, noProvenance), []);
    assert.notDeepEqual(check(messageSchema, { ...good(), timeframes: ["H2"] }), []);
  });
});

describe("no drift between code, contracts and configuration", () => {
  it("timeframes agree everywhere", () => {
    const fromSchema = (resultSchema.$defs?.timeframe?.enum ?? []) as string[];
    const fromMessage = (messageSchema.$defs?.timeframe?.enum ?? []) as string[];
    assert.deepEqual([...TIMEFRAMES], instruments.timeframes);
    assert.deepEqual([...TIMEFRAMES], fromSchema);
    assert.deepEqual([...TIMEFRAMES], fromMessage);
  });

  it("states and directions agree with the schema", () => {
    assert.deepEqual([...EVENT_STATES], resultSchema.properties?.state?.enum);
    assert.deepEqual([...DIRECTIONS], resultSchema.properties?.direction?.enum);
  });

  it("schema version agrees with the code", () => {
    assert.equal(resultSchema.properties?.schema_version?.const, SCHEMA_VERSION);
    assert.equal(messageSchema.properties?.schema_version?.const, SCHEMA_VERSION);
  });

  it("every schema field is produced by toWire, and vice versa", () => {
    const produced = Object.keys(toWire(stamped())).sort();
    assert.deepEqual(produced, Object.keys(resultSchema.properties ?? {}).sort());
    assert.deepEqual([...(resultSchema.required ?? [])].sort(), produced);
  });

  it("analysis modes are the two approved activation paths", () => {
    assert.deepEqual([...ANALYSIS_MODES], ["user_triggered", "market_event"]);
  });
});

describe("approved market-structure parameters", () => {
  const ms = load<{
    swings: { internal: { left: number; right: number }; external: { left: number; right: number } };
    retest_required_for_initial_mss: boolean;
    silent_provisional_to_confirmed_transition: boolean;
    displacement: Record<string, unknown>;
  }>("configuration/market-structure.approved.json");

  it("matches APPROVED_DECISIONS.md (2/2 internal, 5/5 external, retest not mandatory, no silent promotion)", () => {
    assert.deepEqual(ms.swings.internal, { left: 2, right: 2 });
    assert.deepEqual(ms.swings.external, { left: 5, right: 5 });
    assert.equal(ms.retest_required_for_initial_mss, false);
    assert.equal(ms.silent_provisional_to_confirmed_transition, false);
  });

  it("leaves unapproved displacement thresholds null instead of guessing", () => {
    assert.equal(ms.displacement.atr_period, null);
    assert.equal(ms.displacement.body_to_atr_threshold, null);
    assert.equal(ms.displacement.close_location_threshold, null);
  });
});
